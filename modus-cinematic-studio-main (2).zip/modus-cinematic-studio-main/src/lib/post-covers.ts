import svcPublishing from "@/assets/svc-publishing.jpg";
import svcBranding from "@/assets/svc-branding.jpg";
import svcAudiobooks from "@/assets/svc-audiobooks.jpg";
import svcTimesSquare from "@/assets/svc-timessquare.jpg";
import svcMarketing from "@/assets/svc-marketing.jpg";
import knowUsCity from "@/assets/know-us-city.jpg";
import svcPress from "@/assets/svc-press.jpg";

/** Featured image per journal post slug. */
export const postCovers: Record<string, string> = {
  "self-publishing-2026": svcPublishing,
  "author-brand-before-book": svcBranding,
  "audiobook-economics": svcAudiobooks,
  "cover-design-that-sells": svcTimesSquare,
  "amazon-ads-teardown": svcMarketing,
  "how-modus-was-built": knowUsCity,
};

export const fallbackCover = svcPress;

export function coverFor(slug: string) {
  return postCovers[slug] ?? fallbackCover;
}
