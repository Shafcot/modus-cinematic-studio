import coverSignals from "@/assets/book-signals-deep-field.jpg";
import coverQuiet from "@/assets/book-quiet-revolution.jpg";
import coverMachines from "@/assets/book-machines-that-dream.jpg";
import coverLetters from "@/assets/book-letters-younger-self.jpg";
import coverTypography from "@/assets/book-typographers-manifesto.jpg";

export const SITE_URL = "https://modus-cinematic-studio.lovable.app";
export const OG_IMAGE = `${SITE_URL}/og-modus.jpg`;

export const CONTACT_EMAIL = "info@modusventure.com";
export const ADDRESS = "1309 Coffeen Avenue, STE 1200, Sheridan, Wyoming 82801";
export const WHATSAPP_DISPLAY = "+1 (307) 449-2918";
export const WHATSAPP_URL = "https://wa.me/13074492918";

export type Book = {
  slug: string;
  title: string;
  author: string;
  price: string;
  wasPrice?: string;
  tag?: "Bestseller" | "New" | "Sale";
  rating: number;
  genre: string;
  cover: string;
  description: string;
  pages: number;
  formats: string;
};

const CDN = "https://ebook.modusventure.com/wp-content/uploads/2026/08";

export const books: Book[] = [
  {
    slug: "the-art-of-strategic-thinking",
    title: "The Art of Strategic Thinking",
    author: "Elena Rostova",
    price: "$14.99",
    wasPrice: "$24.99",
    tag: "Bestseller",
    rating: 1243,
    genre: "Business",
    cover: `${CDN}/book-01-strategic-thinking.jpg`,
    description:
      "A field guide to thinking several moves ahead without losing the thread of the present. Rostova draws on two decades advising operators to show how strategy is built from small, unglamorous decisions — where to look, what to ignore, and when to commit.",
    pages: 288,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "midnight-in-the-garden-of-algorithms",
    title: "Midnight in the Garden of Algorithms",
    author: "James Chen",
    price: "$12.99",
    tag: "New",
    rating: 892,
    genre: "Technology",
    cover: `${CDN}/book-02-midnight-algorithms.jpg`,
    description:
      "A late-night tour through the systems quietly deciding what we read, buy and believe. Chen writes about machine learning the way a novelist writes about a city — by walking its streets and talking to the people who live there.",
    pages: 246,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "the-last-lighthouse-keeper",
    title: "The Last Lighthouse Keeper",
    author: "Isabel Moreau",
    price: "$9.99",
    wasPrice: "$15.99",
    tag: "Bestseller",
    rating: 2156,
    genre: "Fiction",
    cover: `${CDN}/book-03-lighthouse-keeper.jpg`,
    description:
      "On a wind-scoured island, the last keeper of a soon-to-be-automated light counts down his final season. A quiet, salt-bitten novel about obsolescence, memory, and the stubborn dignity of doing a job well.",
    pages: 332,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "echoes-of-ancient-rome",
    title: "Echoes of Ancient Rome",
    author: "Professor Alistair Finch",
    price: "$15.99",
    wasPrice: "$19.99",
    tag: "Sale",
    rating: 1876,
    genre: "History",
    cover: `${CDN}/book-08-echoes-ancient-rome.jpg`,
    description:
      "Rome did not fall so much as it dispersed. Finch traces its administrative habits, engineering and legal instincts through fifteen centuries of European life, arguing that we live inside the empire's afterimage.",
    pages: 412,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "lean-operations-for-startups",
    title: "Lean Operations for Startups",
    author: "Rachel Thompson",
    price: "$14.99",
    tag: "New",
    rating: 312,
    genre: "Business",
    cover: `${CDN}/book-11-lean-operations.jpg`,
    description:
      "The operational playbook most founders write too late. Thompson covers hiring sequences, vendor decisions, cash discipline and the handful of processes worth installing before a company reaches fifty people.",
    pages: 264,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "quantum-consciousness",
    title: "Quantum Consciousness",
    author: "Dr. Priya Sharma",
    price: "$17.99",
    tag: "New",
    rating: 445,
    genre: "Science",
    cover: `${CDN}/book-09-quantum-consciousness.jpg`,
    description:
      "A careful, sceptical survey of where physics and the mind sciences actually meet — and where the popular story runs far ahead of the evidence. Sharma separates the credible research programmes from the metaphors.",
    pages: 298,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "atomic-habits-for-creatives",
    title: "Atomic Habits for Creatives",
    author: "Marcus Webb",
    price: "$11.99",
    tag: "New",
    rating: 678,
    genre: "Self-Improvement",
    cover: `${CDN}/book-04-atomic-habits.jpg`,
    description:
      "Creative work resists routine, which is exactly why it needs one. Webb builds a practice-first system for writers, designers and musicians: small daily commitments, honest measurement, and permission to make bad work on schedule.",
    pages: 218,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "the-typographers-manifesto",
    title: "The Typographer's Manifesto",
    author: "Lucia Bernard",
    price: "$18.99",
    tag: "Bestseller",
    rating: 934,
    genre: "Design",
    cover: coverTypography,
    description:
      "An argument for type as the last honest craft in a screen-shaped world. Bernard moves from metal to variable fonts, insisting throughout that legibility is an ethical position, not a stylistic one.",
    pages: 240,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "signals-from-the-deep-field",
    title: "Signals from the Deep Field",
    author: "Dr. Omar Haddad",
    price: "$16.99",
    rating: 521,
    genre: "Science",
    cover: coverSignals,
    description:
      "What the faintest light in the universe tells us about the first billion years. Haddad turns a decade of observation runs into a lucid account of how modern cosmology actually gets made — slowly, and in the cold.",
    pages: 276,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "the-quiet-revolution",
    title: "The Quiet Revolution",
    author: "Nadia Karim",
    price: "$13.99",
    wasPrice: "$18.99",
    tag: "Sale",
    rating: 1102,
    genre: "Fiction",
    cover: coverQuiet,
    description:
      "Three generations of one family measure their lives against a city that keeps rewriting itself. A patient, luminous novel about the changes that arrive without announcement and never quite leave.",
    pages: 356,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "machines-that-dream",
    title: "Machines That Dream",
    author: "Theo Lindqvist",
    price: "$15.49",
    rating: 733,
    genre: "Technology",
    cover: coverMachines,
    description:
      "Generative systems are producing images, music and prose at industrial scale. Lindqvist asks the harder question underneath the hype: what happens to taste, authorship and value when creation becomes cheap.",
    pages: 254,
    formats: "ePub · Kindle · PDF",
  },
  {
    slug: "letters-to-a-younger-self",
    title: "Letters to a Younger Self",
    author: "Amara Osei",
    price: "$10.99",
    tag: "Bestseller",
    rating: 1584,
    genre: "Self-Improvement",
    cover: coverLetters,
    description:
      "Thirty short letters written to the person Osei used to be — on ambition, money, grief, friendship and the long middle stretch nobody warns you about. Plainly written and hard to put down.",
    pages: 192,
    formats: "ePub · Kindle · PDF",
  },
];

export const genres = [
  "Fiction",
  "Business",
  "Self-Improvement",
  "Technology",
  "Science",
  "History",
  "Design",
];

export type Service = {
  slug: string;
  title: string;
  blurb: string;
  detail: string;
  href?: string;
  points: string[];
};

export const services: Service[] = [
  {
    slug: "publishing",
    title: "Publishing",
    blurb: "Manuscript to finished book — editorial, design, formatting, release.",
    detail:
      "A complete end-to-end publishing pipeline. We take a raw manuscript through developmental editing, line editing, proofreading, interior typesetting, cover design and final export to print-ready PDF, ePub and Kindle formats.",
    href: "/publishing",
    points: [
      "Developmental & line editing",
      "Interior typesetting and layout",
      "Cover art direction and design",
      "ISBN, metadata and copyright registration",
    ],
  },
  {
    slug: "global-publishing",
    title: "Global Publishing",
    href: "/global-publishing",
    blurb: "Distribution across Amazon, Apple Books, Kobo, Google Play and 40+ retailers.",
    detail:
      "Your title, live everywhere readers buy. We handle retailer onboarding, regional pricing, territory rights, and library distribution so a single manuscript reaches a genuinely international audience.",
    points: [
      "40+ retail and library channels",
      "Regional pricing and territory rights",
      "Print-on-demand fulfilment",
      "Royalty reporting dashboards",
    ],
  },
  {
    slug: "author-branding",
    title: "Author Branding",
    blurb: "Identity, positioning and the visual language that makes an author unmistakable.",
    detail:
      "An author is a brand before the book is a product. We build the positioning, voice, visual identity, author site and social presence that make a name memorable long after the launch week ends.",
    href: "/author-branding",
    points: [
      "Positioning and messaging strategy",
      "Logo, typography and visual identity",
      "Author website and media kit",
      "Photography art direction",
    ],
  },
  {
    slug: "author-marketing",
    title: "Author Marketing",
    blurb: "Launch campaigns, paid media and reader acquisition that actually convert.",
    detail:
      "Data-led launch and evergreen campaigns. Pre-order funnels, Amazon Ads, Meta and TikTok creative, newsletter swaps, ARC reader programs and review generation — measured against sales, not impressions.",
    href: "/author-marketing",
    points: [
      "Pre-order and launch-week funnels",
      "Amazon, Meta and TikTok paid media",
      "ARC and review generation programs",
      "Email list building and automation",
    ],
  },
  {
    slug: "audiobooks",
    title: "Audiobooks",
    blurb: "Professional narration, mastering and distribution to Audible and beyond.",
    detail:
      "Studio-grade audiobook production. Narrator casting, directed recording sessions, ACX-compliant mastering, and distribution to Audible, Spotify, Apple Books and Findaway Voices.",
    href: "/audiobooks",
    points: [
      "Narrator casting and voice matching",
      "Directed studio recording",
      "ACX-compliant mastering and QC",
      "Distribution to all major platforms",
    ],
  },
  {
    slug: "podcast",
    title: "Podcast",
    href: "/podcast",
    blurb: "Turn a book into an ongoing show — production, editing, and guest booking.",
    detail:
      "We build author-led shows end to end: format design, episode production, editing, show art, transcripts, and a booking pipeline that places our authors on established podcasts too.",
    points: [
      "Show format and season planning",
      "Full episode production and editing",
      "Show art and audiogram assets",
      "Guest booking on partner shows",
    ],
  },
  {
    slug: "times-square-advertising",
    title: "Times Square Advertising",
    href: "/times-square-advertising",
    blurb: "Your cover on the world's most photographed billboard, with the footage to prove it.",
    detail:
      "Large-format digital placements in Times Square with professional capture. A single spot becomes a press asset, a social reel, and a credibility marker that follows the book everywhere.",
    points: [
      "Billboard creative design",
      "Scheduled digital placement",
      "Professional video and photo capture",
      "Social-ready cutdowns",
    ],
  },
  {
    slug: "press-releases",
    title: "Press Releases",
    href: "/press-releases",
    blurb: "Written, distributed and pitched to outlets that matter in your category.",
    detail:
      "Newsroom-quality releases written by editors who know the beat, distributed across syndicated wires and pitched directly to journalists covering your subject area.",
    points: [
      "Editor-written release copy",
      "Syndicated wire distribution",
      "Targeted journalist outreach",
      "Coverage reporting",
    ],
  },
];

export const differences = [
  {
    num: "01",
    title: "Curated Selection",
    body: "Every title is handpicked by our editorial team for quality and relevance.",
  },
  {
    num: "02",
    title: "Instant Delivery",
    body: "Your ebook arrives in your inbox within minutes. No waiting, no shipping.",
  },
  {
    num: "03",
    title: "Read Anywhere",
    body: "PDF and ePub formats compatible with all devices — Kindle, tablet, phone.",
  },
  {
    num: "04",
    title: "Personal Support",
    body: "Questions? Our team responds to every inquiry within 24 hours.",
  },
];

export const stats = [
  { value: 500, suffix: "+", label: "Titles published" },
  { value: 120, suffix: "+", label: "Authors represented" },
  { value: 30, suffix: "+", label: "Countries reached" },
  { value: 96, suffix: "%", label: "Authors who return" },
];

export const testimonials = [
  {
    quote:
      "Modus took a manuscript I'd sat on for four years and turned it into a book I'm proud to hand to anyone. The editorial work alone was worth it.",
    name: "Elena Rostova",
    role: "Author, The Art of Strategic Thinking",
    initials: "ER",
  },
  {
    quote:
      "The launch campaign hit number one in two categories in the first week. They treat marketing like engineering — everything measured, nothing guessed.",
    name: "James Chen",
    role: "Author, Midnight in the Garden of Algorithms",
    initials: "JC",
  },
  {
    quote:
      "I came for the audiobook and stayed for everything else. Narration, mastering, distribution — handled without a single chase-up email from me.",
    name: "Isabel Moreau",
    role: "Author, The Last Lighthouse Keeper",
    initials: "IM",
  },
  {
    quote:
      "They built my author brand from nothing. The site, the identity, the press. Publishers started calling me instead of the other way around.",
    name: "Amara Osei",
    role: "Author, Letters to a Younger Self",
    initials: "AO",
  },
  {
    quote:
      "I came in thinking I just needed an editor. Modus rebuilt how I thought about the whole launch — the book performed better than I expected because the groundwork was actually done right.",
    name: "Rachel Thompson",
    role: "Author, Lean Operations for Startups",
    initials: "RT",
  },
  {
    quote:
      "Technical books are hard to make readable without dumbing them down. My editor understood the material well enough to know exactly where I was overexplaining and where I wasn't explaining enough.",
    name: "Dr. Priya Sharma",
    role: "Author, Quantum Consciousness",
    initials: "PS",
  },
  {
    quote:
      "I'd shelved this manuscript twice before. Modus gave me a plan instead of just notes, and that's the difference between a book that gets finished and one that doesn't.",
    name: "Marcus Webb",
    role: "Author, Atomic Habits for Creatives",
    initials: "MW",
  },
  {
    quote:
      "As a designer myself I'm picky about covers. They still surprised me — the art direction was sharper than what I would have landed on alone.",
    name: "Lucia Bernard",
    role: "Author, The Typographer's Manifesto",
    initials: "LB",
  },
  {
    quote:
      "Distribution was the part I dreaded most. Having it handled across every retailer without me managing forty separate accounts was worth the fee by itself.",
    name: "Dr. Omar Haddad",
    role: "Author, Signals from the Deep Field",
    initials: "OH",
  },
  {
    quote:
      "Four different freelancers couldn't get my manuscript where Modus got it in six weeks. Having one team means nothing falls through the cracks.",
    name: "Nadia Karim",
    role: "Author, The Quiet Revolution",
    initials: "NK",
  },
  {
    quote:
      "The launch plan they built kept the book selling three months after release, not just launch week. That's the part most people don't budget for.",
    name: "Theo Lindqvist",
    role: "Author, Machines That Dream",
    initials: "TL",
  },
  {
    quote:
      "I've published through a university press before. This was faster, more collaborative, and honestly better design work.",
    name: "Professor Alistair Finch",
    role: "Author, Echoes of Ancient Rome",
    initials: "AF",
  },
];

export const clients = [
  "Ravenhill Press",
  "Northgate Media",
  "Lumen Books",
  "Aster & Vane",
  "The Quarterly",
  "Halcyon Audio",
];

export type Post = {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  author: string;
  readingTime: string;
  body: string[];
};

const placeholderBody = (topic: string) => [
  `This piece is drawn from work we do every week at Modus, and it starts where most conversations about ${topic} start: with an author who has done the hard part already and now has to make a series of decisions nobody prepared them for.`,
  "The short version is that the decisions compound. A choice made early — about scope, about format, about who the book is genuinely for — sets the ceiling on everything that follows. Fixing it later costs several times what it would have cost to get right at the outset.",
  "What follows is the way our team thinks it through, written plainly and without the trade jargon. None of it is proprietary. We publish it because authors make better partners when they understand the machinery.",
  "First, define the outcome before the tactics. A book intended to build a consulting practice is a different object from a book intended to win a prize, even when the manuscript is identical. Everything downstream — cover, category, price, launch shape — follows from that single answer.",
  "Second, spend where the reader actually looks. Editorial and cover carry disproportionate weight; a great many other line items do not. We are ruthless about this on our own list, and it is usually the advice that saves an author the most money.",
  "Third, plan past launch week. The titles that do well over a year rarely peak in the first seven days. They accumulate reviews, hold a category position, and keep a small, steady advertising floor under them long after the announcement noise has died down.",
  "If you are weighing this for your own book and want a second opinion on the specifics, our editorial desk reads real manuscripts and gives real answers. That conversation is free, and it is usually short.",
];

export const posts: Post[] = [
  {
    slug: "self-publishing-2026",
    title: "What self-publishing actually costs in 2026",
    excerpt:
      "A line-by-line breakdown of editorial, design, production and marketing spend — and where authors consistently overpay.",
    date: "12 Aug 2026",
    category: "Publishing",
    author: "The Modus editorial desk",
    readingTime: "7 min read",
    body: placeholderBody("publishing budgets"),
  },
  {
    slug: "author-brand-before-book",
    title: "Build the author brand before the book",
    excerpt:
      "Why positioning work done twelve months out beats any launch-week campaign, with three case studies from our roster.",
    date: "29 Jul 2026",
    category: "Branding",
    author: "Modus brand studio",
    readingTime: "6 min read",
    body: placeholderBody("author positioning"),
  },
  {
    slug: "audiobook-economics",
    title: "The quiet economics of audiobooks",
    excerpt:
      "Audio is now a third of trade revenue for our titles. Here's how narration budgets and royalty splits really work.",
    date: "04 Jul 2026",
    category: "Audio",
    author: "Modus audio production",
    readingTime: "8 min read",
    body: placeholderBody("audiobook production"),
  },
  {
    slug: "cover-design-that-sells",
    title: "Cover design that survives a thumbnail",
    excerpt:
      "Most covers are judged at 60 pixels wide. A practical framework for designing for the scroll, not the shelf.",
    date: "18 Jun 2026",
    category: "Design",
    author: "Modus design studio",
    readingTime: "5 min read",
    body: placeholderBody("cover design"),
  },
  {
    slug: "amazon-ads-teardown",
    title: "An Amazon Ads teardown of a six-figure launch",
    excerpt:
      "Real keyword sets, real ACOS numbers, and the three structural mistakes that drain most author ad budgets.",
    date: "02 Jun 2026",
    category: "Marketing",
    author: "Modus growth team",
    readingTime: "9 min read",
    body: placeholderBody("paid media for books"),
  },
  {
    slug: "how-modus-was-built",
    title: "From one desk to worldwide: how Modus was built",
    excerpt:
      "The studio's origin story — founded in the United States, now working with authors and creative partners around the world.",
    date: "21 May 2026",
    category: "Studio",
    author: "The Modus editorial desk",
    readingTime: "6 min read",
    body: placeholderBody("building a publishing house"),
  },
];
