import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { Tilt } from "@/components/motion-primitives";
import type { Book } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export function BookCard({ book, index = 0 }: { book: Book; index?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.92 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
      className="h-full"
    >
      <Tilt strength={8} className="h-full">
        <Link
          to="/catalog/$slug"
          params={{ slug: book.slug }}
          className="block h-full"
          aria-label={`${book.title} by ${book.author}`}
        >
          <article className="group relative flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface/60 transition-all duration-500 hover:-translate-y-2 hover:border-primary/60 hover:shadow-[0_30px_80px_-30px_var(--primary)]">
            <div className="duotone relative aspect-[3/4] overflow-hidden bg-surface-2">
              <img
                src={book.cover}
                alt={`${book.title} cover`}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-[1.2s] group-hover:scale-107"
              />
              {book.tag ? (
                <span
                  className={cn(
                    "absolute top-3 left-3 z-10 rounded-full px-3 py-1 text-[0.6rem] tracking-[0.18em] uppercase",
                    book.tag === "Bestseller" && "bg-primary text-primary-foreground",
                    book.tag === "New" && "border border-primary/60 bg-background/70 text-primary",
                    book.tag === "Sale" && "bg-primary-deep text-foreground",
                  )}
                >
                  {book.tag}
                </span>
              ) : null}
            </div>

            <div className="flex flex-1 flex-col p-5">
              <p className="text-[0.6rem] tracking-[0.22em] text-muted-foreground uppercase">
                {book.genre}
              </p>
              <h3 className="mt-2 font-serif text-lg leading-tight font-light">
                {book.title}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">{book.author}</p>
              <div className="mt-auto flex items-end justify-between pt-5">
                <div className="flex items-baseline gap-2">
                  <span className="text-base font-medium text-primary">{book.price}</span>
                  {book.wasPrice ? (
                    <span className="text-xs text-muted-foreground line-through">
                      {book.wasPrice}
                    </span>
                  ) : null}
                </div>
                <span className="text-[0.65rem] text-muted-foreground">
                  ★ {book.rating.toLocaleString()}
                </span>
              </div>
            </div>
          </article>
        </Link>
      </Tilt>
    </motion.div>
  );
}
