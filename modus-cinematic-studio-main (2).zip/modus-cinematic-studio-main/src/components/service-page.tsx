import { motion } from "framer-motion";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, PageHero, Section, SectionHeading } from "@/components/ui-kit";
import { CountUp, ImageReveal, Reveal } from "@/components/motion-primitives";

export type ServiceStat = { value: number; suffix?: string; label: string };
export type ServiceStep = { n: string; title: string; body: string };
export type ServiceBenefit = { title: string; body: string };

export type ServicePageProps = {
  eyebrow: string;
  title: string;
  serifPart: string;
  intro: string;
  heroImage: string;
  overview: {
    eyebrow: string;
    title: string;
    serifPart: string;
    paragraphs: string[];
    image: string;
    imageAlt: string;
  };
  benefitsHeading: { eyebrow: string; title: string; serifPart: string; intro: string };
  benefits: ServiceBenefit[];
  stats: ServiceStat[];
  stepsHeading: { eyebrow: string; title: string; serifPart: string; intro: string };
  steps: ServiceStep[];
  ctaImage: string;
  ctaTitle: string;
  ctaSerif: string;
  ctaLabel: string;
};

export function ServiceDetailPage(p: ServicePageProps) {
  return (
    <SiteLayout>
      <PageHero
        eyebrow={p.eyebrow}
        title={p.title}
        serifPart={p.serifPart}
        intro={p.intro}
        image={p.heroImage}
      />

      <Section>
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow={p.overview.eyebrow}
              title={p.overview.title}
              serifPart={p.overview.serifPart}
            />
            <Reveal delay={0.15}>
              {p.overview.paragraphs.map((text, i) => (
                <p
                  key={i}
                  className={`leading-relaxed text-muted-foreground ${i === 0 ? "mt-7" : "mt-4"}`}
                >
                  {text}
                </p>
              ))}
              <ButtonLink to="/contact" className="mt-9" magnetic>
                {p.ctaLabel}
              </ButtonLink>
            </Reveal>
          </div>
          <ImageReveal
            src={p.overview.image}
            alt={p.overview.imageAlt}
            className="aspect-[4/5] rounded-xl"
            parallax={60}
          />
        </div>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow={p.benefitsHeading.eyebrow}
          title={p.benefitsHeading.title}
          serifPart={p.benefitsHeading.serifPart}
          intro={p.benefitsHeading.intro}
        />
        <div className="mt-14 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {p.benefits.map((b, i) => (
            <Reveal key={b.title} delay={i * 0.08}>
              <div className="group h-full bg-background p-8 transition-colors duration-500 hover:bg-surface">
                <span className="font-serif text-5xl font-light text-primary/40 transition-colors duration-500 group-hover:text-primary">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-6 text-lg font-medium">{b.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {b.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-6 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {p.stats.map((s) => (
            <div key={s.label} className="bg-surface/60 p-8 text-center">
              <p className="font-serif text-5xl font-light md:text-6xl">
                <CountUp to={s.value} suffix={s.suffix ?? ""} />
              </p>
              <p className="mt-3 text-[0.68rem] tracking-[0.22em] text-muted-foreground uppercase">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow={p.stepsHeading.eyebrow}
          title={p.stepsHeading.title}
          serifPart={p.stepsHeading.serifPart}
          intro={p.stepsHeading.intro}
        />
        <div className="relative mt-16 pl-8 md:pl-0">
          <span className="absolute top-0 bottom-0 left-[3px] w-px bg-gradient-to-b from-primary via-primary/40 to-transparent md:left-1/2" />
          {p.steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.06}>
              <div
                className={`relative flex py-9 md:w-1/2 ${
                  i % 2 ? "md:ml-auto md:pl-14" : "md:pr-14 md:text-right"
                }`}
              >
                <motion.span
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  className={`absolute top-11 -left-8 size-2 rounded-full bg-primary shadow-[0_0_0_5px_var(--primary-deep)] md:top-11 ${
                    i % 2 ? "md:-left-1" : "md:-right-1 md:left-auto"
                  }`}
                />
                <div>
                  <span className="font-serif text-4xl font-light text-primary/50">
                    {s.n}
                  </span>
                  <h3 className="mt-3 text-2xl font-medium">{s.title}</h3>
                  <p className="mt-3 leading-relaxed text-muted-foreground">{s.body}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      <section className="relative flex min-h-[55vh] items-center overflow-hidden border-t border-border">
        <div className="duotone grain absolute inset-0">
          <img
            src={p.ctaImage}
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative mx-auto w-full max-w-4xl px-6 text-center">
          <h2 className="font-serif text-4xl leading-[1.05] font-light md:text-6xl">
            {p.ctaTitle} <span className="italic text-primary">{p.ctaSerif}</span>
          </h2>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <ButtonLink to="/services" variant="outline">
              All services
            </ButtonLink>
            <ButtonLink to="/contact" magnetic>
              Get in touch
            </ButtonLink>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
