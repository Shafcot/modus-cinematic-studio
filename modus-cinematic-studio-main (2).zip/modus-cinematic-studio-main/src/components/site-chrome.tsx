import { Link } from "@tanstack/react-router";
import { AnimatePresence, motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useState, type ReactNode } from "react";
import { Logo, ModusMark } from "@/components/brand";
import { ButtonLink } from "@/components/ui-kit";
import { SmoothScroll } from "@/components/motion-primitives";
import { Mail, MapPin, MessageCircle } from "lucide-react";
import {
  ADDRESS,
  CONTACT_EMAIL,
  WHATSAPP_DISPLAY,
  WHATSAPP_URL,
} from "@/lib/site-data";
import { cn } from "@/lib/utils";

export const navLinks = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/publishing", label: "Publishing" },
  { to: "/author-branding", label: "Author Branding" },
  { to: "/author-marketing", label: "Author Marketing" },
  { to: "/audiobooks", label: "Audiobooks" },
  { to: "/catalog", label: "Catalog" },
  { to: "/blog", label: "Blog" },
  { to: "/contact", label: "Contact" },
];

// Full list of every page, used in the mobile menu and footer, where there is room.
export const allLinks = [
  { to: "/", label: "Home" },
  { to: "/about", label: "Our Story" },
  { to: "/services", label: "Services" },
  { to: "/publishing", label: "Publishing" },
  { to: "/global-publishing", label: "Global Publishing" },
  { to: "/author-branding", label: "Author Branding" },
  { to: "/author-marketing", label: "Author Marketing" },
  { to: "/audiobooks", label: "Audiobooks" },
  { to: "/podcast", label: "Podcast" },
  { to: "/times-square-advertising", label: "Times Square Advertising" },
  { to: "/press-releases", label: "Press Releases" },
  { to: "/catalog", label: "Catalog" },
  { to: "/blog", label: "Blog" },
  { to: "/contact", label: "Contact" },
];

function Nav() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, "change", (v) => setSolid(v > 40));

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          solid
            ? "border-b border-border bg-background/85 py-3 backdrop-blur-xl"
            : "border-b border-transparent py-6",
        )}
      >
        <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-6 px-6 md:px-10">
          <Logo compact />

          <nav className="hidden flex-nowrap items-center gap-x-5 xl:flex 2xl:gap-x-6">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                activeOptions={{ exact: l.to === "/" }}
                className="group relative inline-flex items-center text-[0.75rem] leading-none tracking-[0.06em] whitespace-nowrap text-muted-foreground uppercase transition-colors hover:text-foreground data-[status=active]:text-foreground"
              >
                {l.label}
                <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-primary transition-all duration-300 group-hover:w-full group-data-[status=active]:w-full" />
              </Link>
            ))}
          </nav>

          <div className="flex shrink-0 items-center gap-3">
            <ButtonLink
              to="/contact"
              className="hidden px-6 py-2.5 text-[0.7rem] whitespace-nowrap lg:inline-flex"
              magnetic
            >
              Start a project
            </ButtonLink>
            <button
              aria-label="Open menu"
              onClick={() => setOpen(true)}
              className="flex size-10 cursor-pointer flex-col items-center justify-center gap-1.5 rounded-full border border-border-strong transition-colors hover:border-primary xl:hidden"
            >
              <span className="block h-px w-4 bg-foreground" />
              <span className="block h-px w-4 bg-foreground" />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-background/98 px-5 py-6 backdrop-blur-xl sm:px-6"
          >
            <div className="flex items-center justify-between">
              <ModusMark className="h-8" />
              <button
                aria-label="Close menu"
                onClick={() => setOpen(false)}
                className="size-10 cursor-pointer rounded-full border border-border-strong text-lg transition-colors hover:border-primary hover:text-primary"
              >
                ×
              </button>
            </div>
            <nav className="mt-10 flex flex-1 flex-col justify-center gap-1 pb-4">
              {allLinks.map((l, i) => (
                <motion.div
                  key={l.to}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.06 * i, duration: 0.5 }}
                >
                  <Link
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className="block border-b border-border py-3.5 font-serif text-2xl font-light transition-colors hover:text-primary sm:text-3xl"
                  >
                    {l.label}
                  </Link>
                </motion.div>
              ))}
            </nav>
            <ButtonLink to="/contact" className="mt-8 w-full">
              Start a project
            </ButtonLink>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  );
}

function Footer() {
  return (
    <footer className="relative border-t border-border bg-surface/40 px-5 pt-16 pb-10 sm:px-6 sm:pt-20 md:px-10">
      <div className="mx-auto w-full max-w-7xl">
        <div className="grid gap-14 md:grid-cols-2 lg:grid-cols-[1.4fr_0.8fr_0.8fr_1.2fr]">
          <div>
            <Logo />
            <p className="mt-6 max-w-sm font-serif text-2xl leading-snug font-light italic text-muted-foreground">
              From finished manuscript to bestseller — under one roof.
            </p>
          </div>

          <div>
            <p className="eyebrow mb-5">Pages</p>
            <ul className="space-y-2.5">
              {allLinks.slice(0, Math.ceil(allLinks.length / 2)).map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-5">More</p>
            <ul className="space-y-2.5">
              {allLinks.slice(Math.ceil(allLinks.length / 2)).map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-5">Get in touch</p>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                <span className="text-sm leading-relaxed text-muted-foreground">
                  {ADDRESS}
                </span>
              </li>
              <li className="flex items-start gap-3">
                <MessageCircle
                  className="mt-0.5 size-4 shrink-0 text-primary"
                  aria-hidden
                />
                <a
                  href={WHATSAPP_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm text-muted-foreground transition-colors hover:text-primary"
                >
                  {WHATSAPP_DISPLAY}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                <a
                  href={`mailto:${CONTACT_EMAIL}`}
                  className="text-sm break-all text-muted-foreground transition-colors hover:text-primary"
                >
                  {CONTACT_EMAIL}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="hairline mt-16" />
        <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p>Modus Publications — a subsidiary of ModusVenture.</p>
          <p>© {new Date().getFullYear()} All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <SmoothScroll />
      <Nav />
      <main>{children}</main>
      <Footer />
    </div>
  );
}
