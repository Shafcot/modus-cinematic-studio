import { Link } from "@tanstack/react-router";
import type { ComponentProps, ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Magnetic, Reveal, SplitText } from "@/components/motion-primitives";

/* --------------------------------- Button --------------------------------- */

const base =
  "relative inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full px-7 py-3.5 text-[0.8rem] leading-none font-medium tracking-[0.14em] uppercase transition-all duration-300 cursor-pointer";

const variants = {
  solid:
    "bg-primary text-primary-foreground hover:bg-primary-dark shadow-[0_10px_40px_-12px_var(--primary)]",
  outline:
    "border border-border-strong text-foreground hover:border-primary hover:text-primary",
  ghost: "text-muted-foreground hover:text-primary",
} as const;

export function Button({
  variant = "solid",
  className,
  children,
  ...rest
}: ComponentProps<"button"> & { variant?: keyof typeof variants }) {
  return (
    <button className={cn(base, variants[variant], className)} {...rest}>
      {children}
    </button>
  );
}

export function ButtonLink({
  to,
  variant = "solid",
  className,
  children,
  magnetic = false,
}: {
  to: string;
  variant?: keyof typeof variants;
  className?: string;
  children: ReactNode;
  magnetic?: boolean;
}) {
  const el = (
    <Link to={to} className={cn(base, variants[variant], className)}>
      {children}
    </Link>
  );
  return magnetic ? <Magnetic>{el}</Magnetic> : el;
}

/* ----------------------------- SectionHeading ----------------------------- */

export function SectionHeading({
  eyebrow,
  title,
  serifPart,
  intro,
  align = "left",
  action,
}: {
  eyebrow?: string;
  title: string;
  serifPart?: string;
  intro?: string;
  align?: "left" | "center";
  action?: ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-5 md:flex-row md:items-end md:justify-between",
        align === "center" && "md:flex-col md:items-center md:text-center",
      )}
    >
      <div className={cn("max-w-2xl", align === "center" && "mx-auto")}>
        {eyebrow ? (
          <Reveal>
            <div className="eyebrow mb-4 flex items-center gap-3">
              <span className="inline-block h-px w-8 bg-primary" />
              {eyebrow}
            </div>
          </Reveal>
        ) : null}
        <h2 className="text-4xl leading-[1.05] font-medium md:text-6xl">
          <SplitText text={title} />
          {serifPart ? (
            <>
              {" "}
              <SplitText
                text={serifPart}
                wordClassName="font-serif italic font-light text-primary"
                delay={0.15}
              />
            </>
          ) : null}
        </h2>
        {intro ? (
          <Reveal delay={0.15}>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              {intro}
            </p>
          </Reveal>
        ) : null}
      </div>
      {action ? <Reveal delay={0.2}>{action}</Reveal> : null}
    </div>
  );
}

/* ---------------------------------- Card ---------------------------------- */

export function Card({
  className,
  children,
  glow = false,
}: {
  className?: string;
  children: ReactNode;
  glow?: boolean;
}) {
  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-xl border border-border bg-surface/60 backdrop-blur-sm transition-all duration-500",
        "hover:border-primary/60",
        glow && "hover:shadow-[0_24px_70px_-24px_var(--primary)]",
        className,
      )}
    >
      {children}
    </div>
  );
}

/* --------------------------------- Section -------------------------------- */

export function Section({
  className,
  children,
  id,
}: {
  className?: string;
  children: ReactNode;
  id?: string;
}) {
  return (
    <section
      id={id}
      className={cn("relative px-5 py-20 sm:px-6 sm:py-24 md:px-10 md:py-32", className)}
    >
      <div className="mx-auto w-full max-w-7xl">{children}</div>
    </section>
  );
}

/* -------------------------------- PageHero -------------------------------- */

export function PageHero({
  eyebrow,
  title,
  serifPart,
  intro,
  image,
}: {
  eyebrow: string;
  title: string;
  serifPart?: string;
  intro: string;
  image: string;
}) {
  return (
    <header className="relative flex min-h-[62vh] items-end overflow-hidden px-5 pt-36 pb-14 sm:px-6 sm:pt-40 sm:pb-16 md:px-10 md:pb-24">
      <div className="duotone grain absolute inset-0">
        <img
          src={image}
          alt=""
          aria-hidden
          className="h-full w-full scale-110 object-cover opacity-70"
        />
      </div>
      <div className="relative mx-auto w-full max-w-7xl">
        <div className="eyebrow mb-5 flex items-center gap-3">
          <span className="inline-block h-px w-8 bg-primary" />
          {eyebrow}
        </div>
        <h1 className="max-w-4xl text-5xl leading-[1.02] font-medium md:text-8xl">
          <SplitText text={title} />
          {serifPart ? (
            <>
              {" "}
              <SplitText
                text={serifPart}
                wordClassName="font-serif italic font-light text-primary"
                delay={0.12}
              />
            </>
          ) : null}
        </h1>
        <Reveal delay={0.3}>
          <p className="mt-7 max-w-xl text-lg leading-relaxed text-muted-foreground">
            {intro}
          </p>
        </Reveal>
      </div>
    </header>
  );
}
