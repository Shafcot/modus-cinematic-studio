import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function ModusMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 110"
      className={cn("h-8 w-auto", className)}
      role="img"
      aria-label="Modus Publications mark"
    >
      <defs>
        <mask id="modus-m-cut">
          <rect width="100" height="110" fill="white" />
          <polygon points="16,0 84,0 50,58" fill="black" />
          <polygon points="0,0 13,0 45,110 29,110" fill="black" />
          <polygon points="87,0 100,0 71,110 55,110" fill="black" />
        </mask>
      </defs>
      <rect width="100" height="110" fill="var(--primary)" mask="url(#modus-m-cut)" />
    </svg>
  );
}

export function Logo({
  className,
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  return (
    <Link to="/" className={cn("flex items-center gap-3", className)}>
      <ModusMark className={compact ? "h-7" : "h-9"} />
      <span className="flex flex-col leading-none">
        <span className="font-serif text-lg tracking-[0.06em] md:text-xl">MODUS</span>
        <span className="mt-0.5 text-[0.55rem] tracking-[0.42em] text-muted-foreground">
          PUBLICATIONS
        </span>
      </span>
    </Link>
  );
}
