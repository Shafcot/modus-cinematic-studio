import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, Card, PageHero, Section, SectionHeading } from "@/components/ui-kit";
import { CountUp, ImageReveal, Reveal } from "@/components/motion-primitives";

import svcMarketing from "@/assets/svc-marketing.jpg";
import svcTimesSquare from "@/assets/svc-timessquare.jpg";
import svcPress from "@/assets/svc-press.jpg";

const TITLE = "Author Marketing — Modus Publications";
const DESC =
  "Launch campaigns, paid media, ARC programs and reader acquisition measured against sales, not impressions.";

export const Route = createFileRoute("/author-marketing")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: AuthorMarketingPage,
});

const metrics = [
  { value: 214, suffix: "", label: "Books launched" },
  { value: 640, suffix: "+", label: "Campaigns run" },
  { value: 3, suffix: ".8x", label: "Median return on ad spend" },
  { value: 71, suffix: "%", label: "Titles charting in week one" },
];

const phases = [
  {
    n: "01",
    title: "Pre-launch",
    body: "Audience research, comp-title analysis, ARC reader recruitment and a pre-order funnel built twelve weeks out.",
  },
  {
    n: "02",
    title: "Launch week",
    body: "Coordinated paid media across Amazon, Meta and TikTok, newsletter swaps, review velocity and category targeting.",
  },
  {
    n: "03",
    title: "Evergreen",
    body: "Always-on ads tuned monthly, backlist bundling, price promotions and an email engine that keeps selling in month nine.",
  },
];

const channels = [
  "Amazon Ads",
  "Meta & Instagram",
  "TikTok creative",
  "BookBub features",
  "Newsletter swaps",
  "Goodreads campaigns",
  "Podcast placements",
  "Influencer seeding",
];

function AuthorMarketingPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Service · Author Marketing"
        title="Campaigns measured in"
        serifPart="sales, not impressions."
        intro="Data-led launches and evergreen campaigns built by a team that reports on royalties, not reach."
        image={svcMarketing}
      />

      <Section>
        <div className="grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {metrics.map((m) => (
            <div key={m.label} className="bg-surface/60 p-8 text-center">
              <p className="font-serif text-5xl font-light md:text-6xl">
                <CountUp to={m.value} suffix={m.suffix} />
              </p>
              <p className="mt-3 text-[0.68rem] tracking-[0.22em] text-muted-foreground uppercase">
                {m.label}
              </p>
            </div>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow="How a campaign runs"
          title="Three phases,"
          serifPart="twelve months."
          intro="A launch is a moment. A campaign is a year. We plan for both from the first call."
        />
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {phases.map((p, i) => (
            <Reveal key={p.n} delay={i * 0.08}>
              <Card glow className="h-full p-8">
                <span className="font-serif text-4xl font-light text-primary/40">
                  {p.n}
                </span>
                <h3 className="mt-5 text-2xl font-medium">{p.title}</h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">{p.body}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow="Channels"
              title="Where your readers"
              serifPart="already are."
              intro="We don't spread budget evenly. We find the two or three channels that move your specific category and push hard there."
            />
            <div className="mt-9 flex flex-wrap gap-2.5">
              {channels.map((c, i) => (
                <Reveal key={c} delay={i * 0.04}>
                  <span className="inline-block rounded-full border border-border px-4 py-2 text-xs tracking-wide text-muted-foreground transition-colors hover:border-primary hover:text-primary">
                    {c}
                  </span>
                </Reveal>
              ))}
            </div>
            <ButtonLink to="/contact" className="mt-10" magnetic>
              Plan a launch
            </ButtonLink>
          </div>
          <ImageReveal
            src={svcTimesSquare}
            alt="Times Square billboards lit up at night"
            className="aspect-[4/3] rounded-xl"
            parallax={40}
          />
        </div>
      </Section>

      <section className="relative flex min-h-[45vh] items-center overflow-hidden border-t border-border">
        <div className="absolute inset-0">
          <img
            src={svcPress}
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover opacity-45 brightness-[0.5]"
          />
          <div className="absolute inset-0 bg-[linear-gradient(175deg,color-mix(in_oklab,var(--background)_60%,transparent),color-mix(in_oklab,var(--primary-deep)_60%,transparent),color-mix(in_oklab,var(--background)_92%,transparent))]" />
        </div>
        <div className="relative mx-auto w-full max-w-4xl px-6 text-center">
          <h2 className="font-serif text-3xl leading-tight font-light italic md:text-5xl">
            “The launch campaign hit number one in two categories in the first
            week. Everything measured, nothing guessed.”
          </h2>
          <p className="mt-6 text-[0.7rem] tracking-[0.26em] text-primary uppercase">
            James Chen
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
