import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, PageHero, Section } from "@/components/ui-kit";
import { Reveal } from "@/components/motion-primitives";
import { services } from "@/lib/site-data";

import bookStack from "@/assets/book-stack.jpg";
import svcPublishing from "@/assets/svc-publishing.jpg";
import svcGlobal from "@/assets/svc-global.jpg";
import svcBranding from "@/assets/svc-branding.jpg";
import svcMarketing from "@/assets/svc-marketing.jpg";
import svcAudiobooks from "@/assets/svc-audiobooks.jpg";
import svcPodcast from "@/assets/svc-podcast.jpg";
import svcTimesSquare from "@/assets/svc-timessquare.jpg";
import svcPress from "@/assets/svc-press.jpg";

const images = [
  svcPublishing,
  svcGlobal,
  svcBranding,
  svcMarketing,
  svcAudiobooks,
  svcPodcast,
  svcTimesSquare,
  svcPress,
];

const TITLE = "Services — Modus Publications";
const DESC =
  "Publishing, global distribution, author branding, marketing, audiobooks, podcasts, Times Square advertising and press releases.";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const [open, setOpen] = useState<string | null>(services[0]!.slug);

  return (
    <SiteLayout>
      <PageHero
        eyebrow="What we do"
        title="Eight services."
        serifPart="One studio."
        intro="Every discipline a book needs, run by people who do only this. Pick one, or hand us the whole thing."
        image={bookStack}
      />

      <Section>
        <div className="border-t border-border">
          {services.map((s, i) => {
            const isOpen = open === s.slug;
            return (
              <Reveal key={s.slug} delay={i * 0.04}>
                <div className="group border-b border-border">
                  <button
                    onClick={() => setOpen(isOpen ? null : s.slug)}
                    className="flex w-full cursor-pointer items-center gap-6 py-7 text-left transition-colors hover:text-primary"
                  >
                    <span className="w-10 shrink-0 text-[0.7rem] tracking-[0.2em] text-primary">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="flex-1 text-2xl font-medium md:text-4xl">
                      {s.title}
                    </span>
                    <span className="hidden max-w-sm flex-1 text-sm text-muted-foreground lg:block">
                      {s.blurb}
                    </span>
                    <span
                      className={`text-2xl text-primary transition-transform duration-500 ${
                        isOpen ? "rotate-45" : ""
                      }`}
                    >
                      +
                    </span>
                  </button>

                  <motion.div
                    initial={false}
                    animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
                    transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
                    className="overflow-hidden"
                  >
                    <div className="grid gap-8 pb-10 md:grid-cols-[1.2fr_1fr]">
                      <div>
                        <p className="max-w-xl leading-relaxed text-muted-foreground">
                          {s.detail}
                        </p>
                        <ul className="mt-6 grid gap-2 sm:grid-cols-2">
                          {s.points.map((p) => (
                            <li
                              key={p}
                              className="flex items-start gap-3 text-sm text-muted-foreground"
                            >
                              <span className="mt-2 block size-1.5 shrink-0 rounded-full bg-primary" />
                              {p}
                            </li>
                          ))}
                        </ul>
                        {s.href ? (
                          <ButtonLink to={s.href} variant="outline" className="mt-8">
                            Go deeper
                          </ButtonLink>
                        ) : null}
                      </div>
                      <div className="duotone relative aspect-[16/10] overflow-hidden rounded-xl">
                        <img
                          src={images[i % images.length]}
                          alt={s.title}
                          loading="lazy"
                          className="h-full w-full object-cover"
                        />
                      </div>
                    </div>
                  </motion.div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </Section>

      <Section className="border-t border-border text-center">
        <h2 className="font-serif text-3xl font-light md:text-5xl">
          Not sure which one you need?
        </h2>
        <div className="mt-8 flex justify-center">
          <ButtonLink to="/contact" magnetic>
            Talk to us
          </ButtonLink>
        </div>
      </Section>
    </SiteLayout>
  );
}
