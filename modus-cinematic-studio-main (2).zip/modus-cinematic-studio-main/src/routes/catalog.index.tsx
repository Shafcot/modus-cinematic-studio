import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { SiteLayout } from "@/components/site-chrome";
import { BookCard } from "@/components/book-card";
import { PageHero, Section } from "@/components/ui-kit";
import { books, genres } from "@/lib/site-data";

import svcPublishing from "@/assets/svc-publishing.jpg";

const TITLE = "Catalog — Modus Publications";
const DESC =
  "Browse the full Modus catalog: fiction, business, self-improvement, technology, science, history and design titles.";

export const Route = createFileRoute("/catalog/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: CatalogPage,
});

function CatalogPage() {
  const [genre, setGenre] = useState<string | null>(null);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return books.filter(
      (b) =>
        (!genre || b.genre === genre) &&
        (!q ||
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q)),
    );
  }, [genre, query]);

  return (
    <SiteLayout>
      <PageHero
        eyebrow="The catalog"
        title="Every title,"
        serifPart="one shelf."
        intro="Curated digital books for the modern reader — delivered as ePub, PDF and Kindle within minutes of purchase."
        image={svcPublishing}
      />

      <Section>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={() => setGenre(null)}
              className={`cursor-pointer rounded-full border px-4 py-2 text-xs tracking-wide transition-colors ${
                genre === null
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:border-primary hover:text-primary"
              }`}
            >
              All
            </button>
            {genres.map((g) => (
              <button
                key={g}
                onClick={() => setGenre(g)}
                className={`cursor-pointer rounded-full border px-4 py-2 text-xs tracking-wide transition-colors ${
                  genre === g
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          <div className="relative w-full lg:w-72">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search title or author"
              aria-label="Search the catalog"
              className="w-full rounded-full border border-border bg-surface/60 px-5 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary"
            />
          </div>
        </div>

        <p className="mt-6 text-xs tracking-[0.18em] text-muted-foreground uppercase">
          {filtered.length} {filtered.length === 1 ? "title" : "titles"}
        </p>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <AnimatePresence mode="popLayout">
            {filtered.map((b, i) => (
              <motion.div
                key={b.title}
                layout
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.35 }}
              >
                <BookCard book={b} index={i % 4} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filtered.length === 0 ? (
          <p className="mt-16 text-center font-serif text-2xl font-light text-muted-foreground italic">
            Nothing matches that yet — try another genre or search.
          </p>
        ) : null}
      </Section>
    </SiteLayout>
  );
}
