import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { ServiceDetailPage } from "@/components/service-page";

import svcGlobal from "@/assets/svc-global.jpg";
import bookStack from "@/assets/book-stack.jpg";
import knowUsCity from "@/assets/know-us-city.jpg";

const TITLE = "Global Publishing — Modus Publications";
const DESC =
  "Distribution to Amazon, Apple Books, Kobo, Google Play and 40+ retail and library channels, with regional pricing, territory rights and royalty reporting.";

export const Route = createFileRoute("/global-publishing")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <ServiceDetailPage
      eyebrow="Service · Global Publishing"
      title="One manuscript,"
      serifPart="forty markets."
      intro="Your title, live everywhere readers actually buy — with the pricing, rights and reporting handled by people who do this every week."
      heroImage={svcGlobal}
      overview={{
        eyebrow: "The service",
        title: "Distribution without",
        serifPart: "the paperwork.",
        paragraphs: [
          "We onboard your book to every channel worth being on: Amazon and Kindle Unlimited, Apple Books, Kobo, Google Play, Barnes & Noble, Scribd, plus the library aggregators that quietly account for a large share of long-tail revenue.",
          "Each retailer has its own metadata rules, pricing logic and promotional calendar. We set your title up correctly the first time — categories, keywords, series linking, pre-order windows — so it is discoverable rather than merely available.",
          "Regional pricing is set market by market rather than by a single currency conversion, and territory rights are configured so you keep the ability to sell rights separately later.",
        ],
        image: knowUsCity,
        imageAlt: "A night skyline representing global reach",
      }}
      benefitsHeading={{
        eyebrow: "Why it matters",
        title: "Reach that",
        serifPart: "compounds.",
        intro: "Distribution is not a one-off upload. It is a position you hold and improve over the life of a title.",
      }}
      benefits={[
        {
          title: "40+ channels",
          body: "Retail, subscription and library platforms across the Americas, Europe, Asia-Pacific and the Middle East.",
        },
        {
          title: "Regional pricing",
          body: "Price points set to local expectations instead of blunt currency conversion, protecting both volume and margin.",
        },
        {
          title: "Print on demand",
          body: "Paperback and hardback fulfilled locally in major markets — no inventory, no shipping delays.",
        },
        {
          title: "Clear royalties",
          body: "One dashboard consolidating every channel, with monthly statements you can actually reconcile.",
        },
      ]}
      stats={[
        { value: 40, suffix: "+", label: "Retail channels" },
        { value: 42, label: "Countries reached" },
        { value: 12, label: "Currencies priced" },
        { value: 72, suffix: "h", label: "Metadata updates" },
      ]}
      stepsHeading={{
        eyebrow: "The process",
        title: "From file",
        serifPart: "to storefront.",
        intro: "Four weeks from approved files to a title live and correctly listed in every market you have rights in.",
      }}
      steps={[
        {
          n: "01",
          title: "Rights and territory map",
          body: "We confirm what you control, where, and in which formats, then build the distribution plan around it.",
        },
        {
          n: "02",
          title: "Metadata build",
          body: "Categories, BISAC codes, keyword sets, comparable titles and descriptions written per retailer, not copy-pasted.",
        },
        {
          n: "03",
          title: "Channel onboarding",
          body: "Accounts, tax forms, format conversion and QA against each platform's technical spec.",
        },
        {
          n: "04",
          title: "Launch and optimise",
          body: "Pre-order windows, price promotions and category adjustments tracked monthly against real sales data.",
        },
      ]}
      ctaImage={bookStack}
      ctaTitle="Put your book where the"
      ctaSerif="readers are."
      ctaLabel="Discuss distribution"
    />
  ),
});
