import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, PageHero, Section, SectionHeading } from "@/components/ui-kit";
import { CountUp, ImageReveal, Reveal } from "@/components/motion-primitives";
import { stats } from "@/lib/site-data";

import knowUsCity from "@/assets/know-us-city.jpg";
import editorialWriter from "@/assets/editorial-writer.jpg";
import inkTexture from "@/assets/ink-texture.jpg";

const TITLE = "Our Story — Modus Publications";
const DESC =
  "Founded in the United States, Modus Publications is a full-service ebook publishing house and creative studio working with authors worldwide.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const values = [
  {
    num: "01",
    title: "Craft before volume",
    body: "We take on a limited list each season so every title gets a senior editor, a real art direction pass, and a launch plan written for that book alone.",
  },
  {
    num: "02",
    title: "Authors keep the wheel",
    body: "Your name is on the cover, so your voice sets the terms. We advise hard, then build exactly the book you decided to make.",
  },
  {
    num: "03",
    title: "One roof, one contact",
    body: "Editing, design, production, audio and marketing sit in the same studio, so nothing is lost between three freelancers and a deadline.",
  },
  {
    num: "04",
    title: "Plain numbers",
    body: "Transparent costs, transparent royalties, and a dashboard you can open any day of the week without asking anyone's permission.",
  },
];

const team = [
  {
    role: "Editorial desk",
    body: "Developmental and line editors drawn from trade publishing, working across literary fiction, memoir and business non-fiction.",
  },
  {
    role: "Design studio",
    body: "Cover art directors and typographers who set interiors for e-readers and print with the same care.",
  },
  {
    role: "Audio & production",
    body: "Narrators, engineers and producers turning finished manuscripts into audiobooks and author podcasts.",
  },
  {
    role: "Growth team",
    body: "Marketers, publicists and retail specialists handling launches, ads, press and long-tail catalog sales.",
  },
];

function AboutPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Know us · Our story"
        title="Founded in the"
        serifPart="United States."
        intro="A two-desk studio with a stack of manuscripts became a full-service publishing house working with authors and creative partners around the world."
        image={knowUsCity}
      />

      <Section>
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow="The beginning"
              title="A stubborn"
              serifPart="belief."
            />
            <Reveal delay={0.15}>
              <p className="mt-7 leading-relaxed text-muted-foreground">
                Modus started as a two-desk studio with a stack of manuscripts and a
                stubborn belief that independent authors deserved the same craft the
                big houses reserve for their lead titles. That belief is still the
                whole business.
              </p>
              <p className="mt-4 leading-relaxed text-muted-foreground">
                Founded in the United States, Modus Publications now works with
                authors and creative partners around the world — editors, designers,
                narrators and marketers who treat every book like it is the only one
                on the list.
              </p>
              <p className="mt-4 leading-relaxed text-muted-foreground">
                What began with editing and cover design has grown into a single
                pipeline: manuscript assessment, production, global distribution,
                audiobooks, author branding and the marketing that keeps a title
                selling long after launch week.
              </p>
            </Reveal>
          </div>
          <ImageReveal
            src={editorialWriter}
            alt="An editor at work by lamplight"
            className="aspect-[4/5] rounded-xl"
            parallax={60}
          />
        </div>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow="Our mission"
          title="Give every author"
          serifPart="a real house."
          intro="We exist to close the gap between an independent author and a lead-title release — the same editorial rigour, the same design standard, the same reach."
        />
        <div className="mt-14 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {values.map((v, i) => (
            <Reveal key={v.num} delay={i * 0.08}>
              <div className="group h-full bg-background p-8 transition-colors duration-500 hover:bg-surface">
                <span className="font-serif text-5xl font-light text-primary/40 transition-colors duration-500 group-hover:text-primary">
                  {v.num}
                </span>
                <h3 className="mt-6 text-lg font-medium">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {v.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-6 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-surface/60 p-8 text-center">
              <p className="font-serif text-5xl font-light md:text-6xl">
                <CountUp to={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-3 text-[0.68rem] tracking-[0.22em] text-muted-foreground uppercase">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow="The team"
          title="Four desks,"
          serifPart="one studio."
          intro="Modus is a small core team in the United States working with a trusted network of specialists across time zones."
        />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((t, i) => (
            <Reveal key={t.role} delay={i * 0.06} className="h-full">
              <div className="h-full rounded-xl border border-border bg-surface/60 p-7 transition-all duration-500 hover:-translate-y-1 hover:border-primary/60">
                <h3 className="text-lg font-medium">{t.role}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {t.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      <section className="relative flex min-h-[55vh] items-center overflow-hidden border-t border-border">
        <div className="duotone grain absolute inset-0">
          <img
            src={inkTexture}
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative mx-auto w-full max-w-4xl px-6 text-center">
          <h2 className="font-serif text-4xl leading-[1.05] font-light md:text-6xl">
            Tell us what you're{" "}
            <span className="italic text-primary">writing.</span>
          </h2>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <ButtonLink to="/services" variant="outline">
              What we do
            </ButtonLink>
            <ButtonLink to="/contact" magnetic>
              Get in touch
            </ButtonLink>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
