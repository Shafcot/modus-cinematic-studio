import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { ServiceDetailPage } from "@/components/service-page";

import svcPress from "@/assets/svc-press.jpg";
import editorialWriter from "@/assets/editorial-writer.jpg";
import bookStack from "@/assets/book-stack.jpg";

const TITLE = "Press Releases — Modus Publications";
const DESC =
  "Editor-written press releases, syndicated wire distribution and targeted journalist outreach for authors and imprints, with coverage reporting.";

export const Route = createFileRoute("/press-releases")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <ServiceDetailPage
      eyebrow="Service · Press Releases"
      title="Written for"
      serifPart="the newsroom."
      intro="Releases drafted by editors who know the beat, distributed on syndicated wires and pitched by hand to the journalists who cover your subject."
      heroImage={svcPress}
      overview={{
        eyebrow: "The service",
        title: "A story, not",
        serifPart: "an announcement.",
        paragraphs: [
          "Most author press releases fail for the same reason: they announce that a book exists. Editors do not publish that. They publish the argument, the data, the timing or the person behind it.",
          "We find the angle first — what about this book intersects with something a newsroom is already covering — and write the release around that. Quotes are drafted with you, then tightened to sound like speech rather than marketing.",
          "Distribution runs on syndicated wires for reach and searchable pickup, and in parallel our team pitches named journalists directly, which is where the coverage that matters usually comes from.",
        ],
        image: editorialWriter,
        imageAlt: "An editor writing by lamplight",
      }}
      benefitsHeading={{
        eyebrow: "Why it matters",
        title: "Coverage that",
        serifPart: "outlives launch.",
        intro: "A wire release stays indexed for years, and a single named piece can carry a title's credibility for its whole life.",
      }}
      benefits={[
        {
          title: "Editor-written copy",
          body: "Drafted by working editors in newsroom style, with an angle chosen against the current news cycle.",
        },
        {
          title: "Wire distribution",
          body: "Syndicated release across national and trade wires with permanent, searchable placements.",
        },
        {
          title: "Direct outreach",
          body: "Personal pitches to named journalists and producers covering your category, not a blast list.",
        },
        {
          title: "Coverage reporting",
          body: "A clean report of pickups, reach and links, delivered two weeks after distribution.",
        },
      ]}
      stats={[
        { value: 500, suffix: "+", label: "Outlets on wire" },
        { value: 120, suffix: "+", label: "Releases placed" },
        { value: 5, suffix: "d", label: "Draft to send" },
        { value: 2, suffix: "wk", label: "Coverage report" },
      ]}
      stepsHeading={{
        eyebrow: "The process",
        title: "Angle, draft,",
        serifPart: "distribution.",
        intro:
          "Ten days from the first angle call to a report showing exactly who ran it.",
      }}
      steps={[
        {
          n: "01",
          title: "Angle session",
          body: "A short call to find the news hook — the argument, the number, the timing or the personal story.",
        },
        {
          n: "02",
          title: "Draft and approval",
          body: "Full release with headline options, boilerplate, quotes and media assets, approved by you before it moves.",
        },
        {
          n: "03",
          title: "Distribution",
          body: "Wire syndication scheduled for the right morning, with regional and trade targeting applied.",
        },
        {
          n: "04",
          title: "Pitching and reporting",
          body: "Direct journalist outreach, interview coordination, and a coverage report with every pickup logged.",
        },
      ]}
      ctaImage={bookStack}
      ctaTitle="Give the press something"
      ctaSerif="to run."
      ctaLabel="Brief our press desk"
    />
  ),
});
