import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { SiteLayout } from "@/components/site-chrome";
import { BookCard } from "@/components/book-card";
import { ButtonLink, Section } from "@/components/ui-kit";
import { Reveal } from "@/components/motion-primitives";
import { books } from "@/lib/site-data";
import { cn } from "@/lib/utils";

import inkTexture from "@/assets/ink-texture.jpg";

export const Route = createFileRoute("/catalog/$slug")({
  loader: ({ params }) => {
    const book = books.find((b) => b.slug === params.slug);
    if (!book) throw notFound();
    return { book };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Title not found — Modus Publications" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const { book } = loaderData;
    const title = `${book.title} by ${book.author} — Modus Publications`;
    const description = book.description.slice(0, 155);
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "book" },
        { name: "twitter:card", content: "summary_large_image" },
        { property: "og:image", content: book.cover },
        { name: "twitter:image", content: book.cover },
      ],
    };
  },
  notFoundComponent: BookNotFound,
  component: BookDetail,
});

function BookNotFound() {
  return (
    <SiteLayout>
      <Section className="pt-48 text-center">
        <h1 className="font-serif text-4xl font-light md:text-6xl">
          We can't find that <span className="italic text-primary">title.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-lg leading-relaxed text-muted-foreground">
          It may have been renamed or moved. The full catalog is one click away.
        </p>
        <div className="mt-10 flex justify-center">
          <ButtonLink to="/catalog" magnetic>
            Back to catalog
          </ButtonLink>
        </div>
      </Section>
    </SiteLayout>
  );
}

function BookDetail() {
  const { book } = Route.useLoaderData();
  const related = books.filter((b) => b.genre === book.genre && b.slug !== book.slug);
  const more = (related.length >= 4 ? related : books.filter((b) => b.slug !== book.slug)).slice(
    0,
    4,
  );

  const facts = [
    { label: "Genre", value: book.genre },
    { label: "Pages", value: String(book.pages) },
    { label: "Formats", value: book.formats },
    { label: "Reader ratings", value: book.rating.toLocaleString() },
  ];

  return (
    <SiteLayout>
      <Section className="pt-40 md:pt-48">
        <Link
          to="/catalog"
          className="group inline-flex items-center gap-2 text-[0.7rem] tracking-[0.2em] text-muted-foreground uppercase transition-colors hover:text-primary"
        >
          <span className="transition-transform duration-300 group-hover:-translate-x-1">
            ←
          </span>
          Back to catalog
        </Link>

        <div className="mt-10 grid gap-14 lg:grid-cols-[0.8fr_1fr]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-xl border border-border bg-surface-2">
              <img
                src={book.cover}
                alt={`${book.title} cover`}
                className="aspect-[3/4] h-full w-full object-cover"
              />
              {book.tag ? (
                <span
                  className={cn(
                    "absolute top-4 left-4 rounded-full px-3 py-1 text-[0.6rem] tracking-[0.18em] uppercase",
                    book.tag === "Bestseller" && "bg-primary text-primary-foreground",
                    book.tag === "New" &&
                      "border border-primary/60 bg-background/70 text-primary",
                    book.tag === "Sale" && "bg-primary-deep text-foreground",
                  )}
                >
                  {book.tag}
                </span>
              ) : null}
            </div>
          </motion.div>

          <div>
            <div className="eyebrow flex items-center gap-3">
              <span className="inline-block h-px w-8 bg-primary" />
              {book.genre}
            </div>
            <h1 className="mt-5 font-serif text-4xl leading-[1.05] font-light md:text-6xl">
              {book.title}
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">{book.author}</p>

            <div className="mt-8 flex items-baseline gap-3">
              <span className="text-3xl font-medium text-primary">{book.price}</span>
              {book.wasPrice ? (
                <span className="text-base text-muted-foreground line-through">
                  {book.wasPrice}
                </span>
              ) : null}
              <span className="text-sm text-muted-foreground">
                ★ {book.rating.toLocaleString()} ratings
              </span>
            </div>

            <p className="mt-8 leading-relaxed text-muted-foreground">
              {book.description}
            </p>

            <dl className="mt-10 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
              {facts.map((f) => (
                <div key={f.label} className="bg-surface/60 p-5">
                  <dt className="text-[0.6rem] tracking-[0.22em] text-muted-foreground uppercase">
                    {f.label}
                  </dt>
                  <dd className="mt-2 text-sm">{f.value}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-10 flex flex-wrap items-center gap-4">
              <ButtonLink to="/contact" magnetic>
                Inquire about this book
              </ButtonLink>
              <ButtonLink to="/catalog" variant="outline">
                Browse the catalog
              </ButtonLink>
            </div>
            <p className="mt-5 text-xs leading-relaxed text-muted-foreground">
              Listings are shown for display. Send us a note and our team will come
              back to you about availability.
            </p>
          </div>
        </div>
      </Section>

      <Section className="border-t border-border">
        <Reveal>
          <h2 className="text-3xl font-medium md:text-4xl">
            More from the{" "}
            <span className="font-serif font-light italic text-primary">catalog.</span>
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {more.map((b, i) => (
            <BookCard key={b.slug} book={b} index={i} />
          ))}
        </div>
      </Section>

      <section className="relative flex min-h-[45vh] items-center overflow-hidden border-t border-border">
        <div className="duotone grain absolute inset-0">
          <img
            src={inkTexture}
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative mx-auto w-full max-w-3xl px-6 text-center">
          <h2 className="font-serif text-3xl leading-tight font-light md:text-5xl">
            Questions about this <span className="italic text-primary">title?</span>
          </h2>
          <div className="mt-9 flex justify-center">
            <ButtonLink to="/contact" magnetic>
              Get in touch
            </ButtonLink>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
