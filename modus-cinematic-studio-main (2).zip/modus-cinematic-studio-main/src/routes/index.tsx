import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef, useState, useEffect } from "react";

import { SiteLayout } from "@/components/site-chrome";
import { BookCard } from "@/components/book-card";
import { ButtonLink, Card, Section, SectionHeading } from "@/components/ui-kit";
import {
  CountUp,
  ImageReveal,
  LineReveal,
  Marquee,
  Reveal,
  SplitText,
} from "@/components/motion-primitives";

import {
  books,
  clients,
  differences,
  services,
  stats,
  testimonials,
} from "@/lib/site-data";

import heroLibrary from "@/assets/hero-library.jpg";
import editorialWriter from "@/assets/editorial-writer.jpg";
import knowUsCity from "@/assets/know-us-city.jpg";
import inkTexture from "@/assets/ink-texture.jpg";
import svcPublishing from "@/assets/svc-publishing.jpg";
import svcGlobal from "@/assets/svc-global.jpg";
import svcBranding from "@/assets/svc-branding.jpg";
import svcMarketing from "@/assets/svc-marketing.jpg";
import svcAudiobooks from "@/assets/svc-audiobooks.jpg";
import svcPodcast from "@/assets/svc-podcast.jpg";
import svcTimesSquare from "@/assets/svc-timessquare.jpg";
import svcPress from "@/assets/svc-press.jpg";

const TITLE = "Modus Publications — Stories that move you";
const DESC =
  "A full-service ebook publishing house and creative studio. Writing, editing, design, publishing, audiobooks and marketing under one roof.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: Home,
});

// Ordered to match the `services` array in site-data
const serviceImages = [
  svcPublishing,
  svcGlobal,
  svcBranding,
  svcMarketing,
  svcAudiobooks,
  svcPodcast,
  svcTimesSquare,
  svcPress,
];

/* ---------------------------------- Hero ---------------------------------- */

function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "28%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-18%"]);
  const fade = useTransform(scrollYProgress, [0, 0.85], [1, 0]);

  return (
    <section
      ref={ref}
      className="relative flex h-screen min-h-[680px] items-center overflow-hidden"
    >
      <motion.div style={{ y: bgY }} className="duotone grain absolute inset-0">
        <img
          src={heroLibrary}
          alt="A reader in a dark library lit by a single shaft of light"
          width={1920}
          height={1088}
          className="h-full w-full object-cover"
          style={{ animation: "ken-burns 26s ease-out forwards" }}
        />
      </motion.div>

      {/* animated red gradient mesh */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div
          className="absolute -top-1/3 left-1/4 size-[70vw] rounded-full bg-[radial-gradient(circle,var(--primary)_0%,transparent_65%)] opacity-25 blur-3xl"
          style={{ animation: "mesh-drift 16s ease-in-out infinite" }}
        />
        <div
          className="absolute right-0 -bottom-1/4 size-[55vw] rounded-full bg-[radial-gradient(circle,var(--primary-deep)_0%,transparent_65%)] opacity-60 blur-3xl"
          style={{ animation: "mesh-drift 22s ease-in-out infinite reverse" }}
        />
      </div>

      <motion.div
        style={{ y: textY, opacity: fade }}
        className="relative mx-auto w-full max-w-7xl px-6 md:px-10"
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="eyebrow mb-7 flex items-center gap-3"
        >
          <span className="inline-block h-px w-10 bg-primary" />
          Publishing house · Creative studio
        </motion.div>

        <LineReveal
          className="text-[3.2rem] leading-[0.95] font-medium tracking-tight md:text-[8vw]"
          lines={[
            <>Stories</>,
            <>
              that <span className="font-serif font-light italic text-primary">move</span>
            </>,
            <>you.</>,
          ]}
          delay={0.25}
        />

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.9 }}
          className="mt-8 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg"
        >
          From finished manuscript to bestseller — writing, editing, design,
          publishing, and marketing under one roof.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.9 }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <ButtonLink to="/catalog" variant="outline">
            Browse catalog
          </ButtonLink>
          <ButtonLink to="/contact" magnetic>
            Start your book
          </ButtonLink>
        </motion.div>
      </motion.div>

      <motion.div
        style={{ opacity: fade }}
        className="absolute inset-x-0 bottom-8 flex justify-center"
      >
        <div
          className="flex flex-col items-center gap-2"
          style={{ animation: "bob 2.4s ease-in-out infinite" }}
        >
          <span className="text-[0.6rem] tracking-[0.3em] text-muted-foreground uppercase">
            Scroll
          </span>
          <span className="block h-10 w-px bg-gradient-to-b from-primary to-transparent" />
        </div>
      </motion.div>
    </section>
  );
}

/* --------------------------- Editorial image break ------------------------- */

function EditorialBreak() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], ["-12%", "12%"]);

  return (
    <div ref={ref} className="relative h-[85vh] min-h-[520px] overflow-hidden">
      <motion.div style={{ y }} className="duotone grain absolute inset-[-12%]">
        <img
          src={editorialWriter}
          alt="A writer working by lamplight in a dark room"
          loading="lazy"
          width={1920}
          height={1088}
          className="h-full w-full object-cover"
        />
      </motion.div>

      <div className="relative flex h-full items-center px-6 md:px-10">
        <motion.blockquote
          initial={{ clipPath: "inset(0 100% 0 0)", opacity: 0 }}
          whileInView={{ clipPath: "inset(0 0% 0 0)", opacity: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
          className="mx-auto w-full max-w-7xl"
        >
          <p className="max-w-3xl font-serif text-3xl leading-[1.15] font-light italic md:text-6xl">
            “A manuscript is only half a book. The other half is everything we
            build around it.”
          </p>
          <footer className="mt-8 text-[0.7rem] tracking-[0.28em] text-primary uppercase">
            The Modus editorial desk
          </footer>
        </motion.blockquote>
      </div>
    </div>
  );
}

/* ------------------------------- Testimonials ------------------------------ */

function Testimonials() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const id = setInterval(
      () => setActive((a) => (a + 1) % testimonials.length),
      6500,
    );
    return () => clearInterval(id);
  }, []);

  return (
    <Section>
      <SectionHeading eyebrow="Kind words" title="What authors" serifPart="say." />
      <div className="mt-14 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        <motion.div
          key={active}
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="relative overflow-hidden rounded-xl border border-border bg-surface/60 p-9 md:p-14"
        >
          <span className="pointer-events-none absolute -top-8 left-6 font-serif text-[10rem] leading-none text-primary/20 select-none">
            “
          </span>
          <p className="relative font-serif text-2xl leading-snug font-light italic md:text-4xl">
            {testimonials[active]!.quote}
          </p>
          <div className="relative mt-9 flex items-center gap-4">
            <span className="flex size-12 items-center justify-center rounded-full border border-primary/50 text-sm tracking-widest text-primary">
              {testimonials[active]!.initials}
            </span>
            <div>
              <p className="text-sm font-medium">{testimonials[active]!.name}</p>
              <p className="text-xs text-muted-foreground">
                {testimonials[active]!.role}
              </p>
            </div>
          </div>
        </motion.div>

        <div className="flex flex-col gap-3">
          {testimonials.map((t, i) => (
            <button
              key={t.name}
              onClick={() => setActive(i)}
              className={`cursor-pointer rounded-xl border p-5 text-left transition-all duration-400 ${
                i === active
                  ? "border-primary/60 bg-surface"
                  : "border-border bg-surface/30 hover:border-border-strong"
              }`}
            >
              <p className="text-sm font-medium">{t.name}</p>
              <p className="mt-1 text-xs text-muted-foreground">{t.role}</p>
            </button>
          ))}
        </div>
      </div>
    </Section>
  );
}

/* ---------------------------------- Page ---------------------------------- */

function Home() {
  return (
    <SiteLayout>
      <Hero />

      {/* Marquee */}
      <div className="relative border-y border-border py-8 md:py-12">
        <Marquee
          items={[
            "publishing",
            "author branding",
            "global distribution",
            "audiobooks",
            "marketing",
            "press",
          ]}
        />
      </div>

      <EditorialBreak />

      {/* Featured titles */}
      <Section>
        <SectionHeading
          eyebrow="Handpicked"
          title="Featured"
          serifPart="titles."
          intro="Curated digital books for the modern reader. From gripping fiction to transformative business insights — delivered instantly."
          action={
            <Link
              to="/catalog"
              className="group inline-flex items-center gap-2 text-[0.75rem] tracking-[0.18em] text-primary uppercase"
            >
              View all
              <span className="transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          }
        />
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {books.slice(0, 4).map((b, i) => (
            <BookCard key={b.title} book={b} index={i} />
          ))}
        </div>
      </Section>

      {/* Services */}
      <Section className="border-t border-border">
        <SectionHeading
          eyebrow="What we do"
          title="Everything a book needs,"
          serifPart="in one studio."
          action={
            <Link
              to="/services"
              className="group inline-flex items-center gap-2 text-[0.75rem] tracking-[0.18em] text-primary uppercase"
            >
              All services
              <span className="transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          }
        />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => {
            const inner = (
              <Card glow className="h-full">
                <div className="absolute inset-0 overflow-hidden">
                  <img
                    src={serviceImages[i % serviceImages.length]}
                    alt=""
                    aria-hidden
                    loading="lazy"
                    className="h-full w-full scale-105 object-cover opacity-60 brightness-[0.62] saturate-[0.85] transition-all duration-[1.2s] group-hover:scale-115 group-hover:opacity-95 group-hover:brightness-100 group-hover:saturate-100"
                  />
                  {/* mid-dark red-black wash — keeps text legible without burying the photo */}
                  <div className="absolute inset-0 bg-[linear-gradient(175deg,color-mix(in_oklab,var(--background)_45%,transparent)_0%,color-mix(in_oklab,var(--primary-deep)_55%,transparent)_45%,color-mix(in_oklab,var(--background)_92%,transparent)_100%)] transition-opacity duration-700 group-hover:opacity-80" />
                </div>

                <div className="relative flex h-full min-h-[240px] flex-col p-6">
                  <span className="flex size-10 items-center justify-center rounded-full border border-primary/40 text-xs text-primary">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="mt-auto text-xl font-medium">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {s.blurb}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-2 text-[0.7rem] tracking-[0.2em] text-primary uppercase">
                    Explore
                    <span className="transition-transform duration-300 group-hover:translate-x-1.5">
                      →
                    </span>
                  </span>
                </div>
              </Card>
            );
            return (
              <Reveal key={s.slug} delay={i * 0.06} className="h-full">
                {s.href ? (
                  <Link to={s.href} className="block h-full">
                    {inner}
                  </Link>
                ) : (
                  <Link to="/services" className="block h-full">
                    {inner}
                  </Link>
                )}
              </Reveal>
            );
          })}
        </div>
      </Section>

      {/* The Modus difference + stats */}
      <Section className="border-t border-border">
        <SectionHeading eyebrow="Why Modus" title="The Modus" serifPart="difference." />
        <div className="mt-14 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {differences.map((d, i) => (
            <Reveal key={d.num} delay={i * 0.08}>
              <div className="group h-full bg-background p-8 transition-colors duration-500 hover:bg-surface">
                <span className="font-serif text-5xl font-light text-primary/40 transition-colors duration-500 group-hover:text-primary">
                  {d.num}
                </span>
                <h3 className="mt-6 text-lg font-medium">{d.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {d.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-6 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-surface/60 p-8 text-center">
              <p className="font-serif text-5xl font-light md:text-6xl">
                <CountUp to={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-3 text-[0.68rem] tracking-[0.22em] text-muted-foreground uppercase">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </Section>

      {/* Know us */}
      <Section className="border-t border-border">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <ImageReveal
            src={knowUsCity}
            alt="A night skyline seen from a studio window"
            className="aspect-[4/5] rounded-xl"
            parallax={60}
            width={1024}
            height={1408}
          />
          <div>
            <div className="eyebrow mb-5 flex items-center gap-3">
              <span className="inline-block h-px w-8 bg-primary" />
              Know us
            </div>
            <h2 className="text-4xl leading-[1.05] font-medium md:text-6xl">
              <SplitText text="Founded in the" />{" "}
              <SplitText
                text="United States."
                wordClassName="font-serif italic font-light text-primary"
                delay={0.15}
              />
            </h2>
            <Reveal delay={0.2}>
              <p className="mt-7 leading-relaxed text-muted-foreground">
                Modus started as a two-desk studio with a stack of manuscripts and
                a stubborn belief that independent authors deserved the same craft
                the big houses reserve for their lead titles. That belief is still
                the whole business.
              </p>
              <p className="mt-4 leading-relaxed text-muted-foreground">
                Founded in the United States, Modus Publications now works with
                authors and creative partners around the world — editors,
                designers, narrators and marketers who treat every book like it is
                the only one on the list.
              </p>
              <Link
                to="/about"
                className="group mt-8 inline-flex items-center gap-2 text-[0.75rem] tracking-[0.18em] text-primary uppercase"
              >
                Our story
                <span className="transition-transform duration-300 group-hover:translate-x-1">
                  →
                </span>
              </Link>
            </Reveal>
          </div>
        </div>
      </Section>

      <Testimonials />

      {/* Clients */}
      <Section className="border-t border-border py-16 md:py-20">
        <p className="eyebrow text-center">Trusted by imprints and partners</p>
        <div className="mt-10 grid grid-cols-2 gap-8 md:grid-cols-6">
          {clients.map((c, i) => (
            <Reveal key={c} delay={i * 0.07}>
              <span className="block text-center font-serif text-lg font-light text-muted-foreground opacity-60 grayscale transition-all duration-500 hover:text-primary hover:opacity-100">
                {c}
              </span>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* Final CTA */}
      <section className="relative flex min-h-[70vh] items-center overflow-hidden">
        <div className="duotone grain absolute inset-0">
          <img
            src={inkTexture}
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto w-full max-w-4xl px-6 text-center"
        >
          <h2 className="font-serif text-4xl leading-[1.05] font-light md:text-7xl">
            Good things happen when you say{" "}
            <span className="italic text-primary">hey.</span>
          </h2>
          <div className="mt-10 flex justify-center">
            <ButtonLink to="/contact" magnetic>
              Get in touch
            </ButtonLink>
          </div>
        </motion.div>
      </section>
    </SiteLayout>
  );
}
