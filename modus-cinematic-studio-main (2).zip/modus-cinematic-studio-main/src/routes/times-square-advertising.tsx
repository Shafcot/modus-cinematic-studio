import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { ServiceDetailPage } from "@/components/service-page";

import svcTimesSquare from "@/assets/svc-timessquare.jpg";
import knowUsCity from "@/assets/know-us-city.jpg";
import inkTexture from "@/assets/ink-texture.jpg";

const TITLE = "Times Square Advertising — Modus Publications";
const DESC =
  "Large-format Times Square billboard placements for authors, with billboard creative, scheduled display and professional photo and video capture.";

export const Route = createFileRoute("/times-square-advertising")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <ServiceDetailPage
      eyebrow="Service · Times Square"
      title="Your cover on"
      serifPart="Broadway."
      intro="A large-format placement on the world's most photographed corner — captured properly, so one night becomes a year of press and social proof."
      heroImage={svcTimesSquare}
      overview={{
        eyebrow: "The service",
        title: "One spot,",
        serifPart: "endless assets.",
        paragraphs: [
          "We book scheduled digital placements on the large-format screens in Times Square and design creative that reads at a hundred metres: cover, name, one line, nothing else.",
          "The placement itself lasts minutes. The reason to do it is what comes back with you — a professional video crew captures the display from the street, giving you a hero reel, stills, and a press asset with a New York dateline.",
          "Authors use that footage on their site, in media kits, in retail A+ content and in pitch emails. It changes how a book is received before anyone has read a page of it.",
        ],
        image: knowUsCity,
        imageAlt: "A neon-lit city skyline at night",
      }}
      benefitsHeading={{
        eyebrow: "Why it matters",
        title: "Credibility you",
        serifPart: "can show.",
        intro: "Nobody sells a book from a billboard. They sell it with the proof that the billboard existed.",
      }}
      benefits={[
        {
          title: "Billboard creative",
          body: "Designed for distance and glare, tested at scale before the booking is confirmed.",
        },
        {
          title: "Scheduled placement",
          body: "Slot booked at a high-footfall hour on a screen we have worked with before, with confirmation of display.",
        },
        {
          title: "Professional capture",
          body: "A crew on the ground shooting video and stills, including crowd context and clean screen frames.",
        },
        {
          title: "Social cutdowns",
          body: "Vertical and square edits, a landscape hero film, and a set of press-ready photographs.",
        },
      ]}
      stats={[
        { value: 330, suffix: "k", label: "Daily footfall" },
        { value: 6, label: "Screen options" },
        { value: 14, suffix: "d", label: "Lead time" },
        { value: 20, suffix: "+", label: "Assets delivered" },
      ]}
      stepsHeading={{
        eyebrow: "The process",
        title: "From cover",
        serifPart: "to Broadway.",
        intro: "Two weeks from brief to footage in your inbox, with everything scheduled around your launch date.",
      }}
      steps={[
        {
          n: "01",
          title: "Brief and booking",
          body: "We pick the screen, the date and the hour, and confirm the slot against your launch calendar.",
        },
        {
          n: "02",
          title: "Creative design",
          body: "Billboard artwork built from your cover and approved by you before it goes to the operator.",
        },
        {
          n: "03",
          title: "Display and capture",
          body: "The placement runs while a crew films the screen and the street from multiple angles.",
        },
        {
          n: "04",
          title: "Edit and delivery",
          body: "Colour-graded film, vertical cutdowns and high-resolution stills delivered within days.",
        },
      ]}
      ctaImage={inkTexture}
      ctaTitle="Put your cover on the"
      ctaSerif="big screen."
      ctaLabel="Book a placement"
    />
  ),
});
