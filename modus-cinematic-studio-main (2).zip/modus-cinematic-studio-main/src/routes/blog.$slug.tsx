import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, Section } from "@/components/ui-kit";
import { Reveal } from "@/components/motion-primitives";
import { posts } from "@/lib/site-data";
import { coverFor } from "@/lib/post-covers";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = posts.find((p) => p.slug === params.slug);
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Article not found — Modus Publications" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const { post } = loaderData;
    const title = `${post.title} — Modus Publications`;
    return {
      meta: [
        { title },
        { name: "description", content: post.excerpt },
        { property: "og:title", content: title },
        { property: "og:description", content: post.excerpt },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: ArticleNotFound,
  component: ArticlePage,
});

function ArticleNotFound() {
  return (
    <SiteLayout>
      <Section className="pt-48 text-center">
        <h1 className="font-serif text-4xl font-light md:text-6xl">
          That piece isn't <span className="italic text-primary">here.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-lg leading-relaxed text-muted-foreground">
          It may have been renamed or moved. Everything we've published is in the
          journal.
        </p>
        <div className="mt-10 flex justify-center">
          <ButtonLink to="/blog" magnetic>
            Back to the journal
          </ButtonLink>
        </div>
      </Section>
    </SiteLayout>
  );
}

function ArticlePage() {
  const { post } = Route.useLoaderData();
  const cover = coverFor(post.slug);
  const more = posts.filter((p) => p.slug !== post.slug).slice(0, 3);

  return (
    <SiteLayout>
      <header className="relative flex min-h-[62vh] items-end overflow-hidden px-6 pt-40 pb-16 md:px-10 md:pb-24">
        <div className="duotone grain absolute inset-0">
          <img
            src={cover}
            alt=""
            aria-hidden
            className="h-full w-full scale-110 object-cover opacity-70"
          />
        </div>
        <div className="relative mx-auto w-full max-w-4xl">
          <div className="flex flex-wrap items-center gap-4 text-[0.65rem] tracking-[0.22em] uppercase">
            <span className="text-primary">{post.category}</span>
            <span className="text-muted-foreground">{post.date}</span>
            <span className="text-muted-foreground">{post.readingTime}</span>
          </div>
          <h1 className="mt-6 font-serif text-4xl leading-[1.05] font-light md:text-6xl">
            {post.title}
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground">
            {post.excerpt}
          </p>
          <p className="mt-6 text-sm text-muted-foreground">By {post.author}</p>
        </div>
      </header>

      <Section>
        <div className="mx-auto max-w-3xl">
          <Link
            to="/blog"
            className="group inline-flex items-center gap-2 text-[0.7rem] tracking-[0.2em] text-muted-foreground uppercase transition-colors hover:text-primary"
          >
            <span className="transition-transform duration-300 group-hover:-translate-x-1">
              ←
            </span>
            All articles
          </Link>

          <div className="mt-10 space-y-6">
            {post.body.map((para, i) => (
              <Reveal key={i} delay={Math.min(i * 0.04, 0.2)}>
                <p
                  className={
                    i === 0
                      ? "font-serif text-xl leading-relaxed font-light text-foreground md:text-2xl"
                      : "leading-relaxed text-muted-foreground"
                  }
                >
                  {para}
                </p>
              </Reveal>
            ))}
          </div>

          <div className="hairline mt-14" />
          <div className="mt-10 flex flex-wrap items-center gap-4">
            <ButtonLink to="/contact" magnetic>
              Talk to our editorial desk
            </ButtonLink>
            <ButtonLink to="/blog" variant="outline">
              More from the journal
            </ButtonLink>
          </div>
        </div>
      </Section>

      <Section className="border-t border-border">
        <h2 className="text-3xl font-medium md:text-4xl">
          Keep <span className="font-serif font-light italic text-primary">reading.</span>
        </h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {more.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.07} className="h-full">
              <Link to="/blog/$slug" params={{ slug: p.slug }} className="block h-full">
                <article className="group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface/60 transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/60 hover:shadow-[0_28px_70px_-30px_var(--primary)]">
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={coverFor(p.slug)}
                      alt=""
                      aria-hidden
                      loading="lazy"
                      className="h-full w-full object-cover opacity-65 brightness-[0.65] transition-all duration-[1.2s] group-hover:scale-108 group-hover:opacity-100 group-hover:brightness-100"
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(175deg,transparent,color-mix(in_oklab,var(--primary-deep)_45%,transparent))]" />
                  </div>
                  <div className="flex flex-1 flex-col p-6">
                    <div className="flex items-center gap-3 text-[0.6rem] tracking-[0.22em] uppercase">
                      <span className="text-primary">{p.category}</span>
                      <span className="text-muted-foreground">{p.date}</span>
                    </div>
                    <h3 className="mt-4 font-serif text-xl leading-snug font-light">
                      {p.title}
                    </h3>
                    <span className="mt-auto pt-6 text-[0.65rem] tracking-[0.2em] text-primary uppercase">
                      Read more →
                    </span>
                  </div>
                </article>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>
    </SiteLayout>
  );
}
