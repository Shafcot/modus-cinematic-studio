import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, Card, PageHero, Section, SectionHeading } from "@/components/ui-kit";
import { ImageReveal, Reveal } from "@/components/motion-primitives";

import svcAudiobooks from "@/assets/svc-audiobooks.jpg";
import svcPodcast from "@/assets/svc-podcast.jpg";

const TITLE = "Audiobooks — Modus Publications";
const DESC =
  "Narrator casting, directed studio recording, ACX-compliant mastering and distribution to Audible, Spotify and Apple Books.";

export const Route = createFileRoute("/audiobooks")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: AudiobooksPage,
});

const BARS = Array.from({ length: 72 }, (_, i) => {
  const wave =
    Math.sin(i * 0.38) * 0.32 + Math.sin(i * 0.11) * 0.4 + Math.sin(i * 0.83) * 0.16;
  return Math.max(0.12, Math.min(1, 0.52 + wave));
});

function Waveform() {
  return (
    <div className="flex h-40 items-center justify-center gap-[3px] md:h-56">
      {BARS.map((h, i) => (
        <motion.span
          key={i}
          className="w-[3px] shrink-0 rounded-full bg-gradient-to-t from-primary-deep via-primary to-primary/40 md:w-[5px]"
          initial={{ scaleY: 0.05, opacity: 0 }}
          whileInView={{ scaleY: h, opacity: 1 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{
            duration: 0.9,
            delay: i * 0.012,
            ease: [0.16, 1, 0.3, 1],
          }}
          style={{ height: "100%", originY: 0.5 }}
        />
      ))}
    </div>
  );
}

const stages = [
  {
    n: "01",
    title: "Casting",
    body: "We audition three to five narrators against a sample chapter and let you pick the voice that sounds like the book in your head.",
  },
  {
    n: "02",
    title: "Direction",
    body: "Every session is directed. Pronunciation guides, character consistency and pacing notes are agreed before the first take.",
  },
  {
    n: "03",
    title: "Mastering",
    body: "Noise floor, RMS and peak levels mastered to ACX and Audible specification, then QC'd chapter by chapter by a human.",
  },
  {
    n: "04",
    title: "Distribution",
    body: "Live on Audible, Spotify, Apple Books, Google Play, Kobo and Findaway Voices, with library channels included.",
  },
];

function AudiobooksPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Service · Audiobooks"
        title="Your book,"
        serifPart="out loud."
        intro="Studio-grade narration, mastering and distribution — a third of trade revenue now comes from audio, and it deserves the same craft as the page."
        image={svcAudiobooks}
      />

      <Section>
        <Reveal>
          <div className="relative overflow-hidden rounded-xl border border-border bg-surface/50 px-6 py-12 md:px-14">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,color-mix(in_oklab,var(--primary)_18%,transparent),transparent_70%)]" />
            <p className="eyebrow relative text-center">Chapter 01 · 38:12</p>
            <div className="relative mt-8">
              <Waveform />
            </div>
            <div className="relative mt-8 flex items-center justify-center gap-6 text-xs tracking-[0.2em] text-muted-foreground uppercase">
              <span>44.1 kHz</span>
              <span className="size-1 rounded-full bg-primary" />
              <span>192 kbps</span>
              <span className="size-1 rounded-full bg-primary" />
              <span>ACX compliant</span>
            </div>
          </div>
        </Reveal>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow="Production"
          title="Four stages,"
          serifPart="one clean master."
        />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {stages.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.07}>
              <Card glow className="h-full p-7">
                <span className="font-serif text-4xl font-light text-primary/40">
                  {s.n}
                </span>
                <h3 className="mt-5 text-xl font-medium">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {s.body}
                </p>
              </Card>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <ImageReveal
            src={svcPodcast}
            alt="A podcast and recording studio desk"
            className="aspect-[4/3] rounded-xl"
            parallax={40}
          />
          <div>
            <SectionHeading
              eyebrow="And after"
              title="Audio doesn't stop at"
              serifPart="the audiobook."
              intro="The same studio, narrator and edit suite can turn your title into a serialised podcast, audiogram assets for social, and sample chapters that work as ads."
            />
            <ButtonLink to="/contact" className="mt-9" magnetic>
              Record your book
            </ButtonLink>
          </div>
        </div>
      </Section>
    </SiteLayout>
  );
}
