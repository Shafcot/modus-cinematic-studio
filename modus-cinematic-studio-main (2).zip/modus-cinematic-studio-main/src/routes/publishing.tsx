import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, PageHero, Section, SectionHeading } from "@/components/ui-kit";
import { ImageReveal, Reveal } from "@/components/motion-primitives";

import pagesMacro from "@/assets/pages-macro.jpg";
import bookStack from "@/assets/book-stack.jpg";
import editorialWriter from "@/assets/editorial-writer.jpg";

const TITLE = "Publishing — Modus Publications";
const DESC =
  "End-to-end book publishing: developmental editing, typesetting, cover design, ISBN and metadata, and release across every major format.";

export const Route = createFileRoute("/publishing")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: PublishingPage,
});

const steps = [
  {
    n: "01",
    title: "Manuscript assessment",
    body: "A senior editor reads the full manuscript and returns a structural report: what works, what drags, and what the book is really about.",
  },
  {
    n: "02",
    title: "Developmental edit",
    body: "Structure, pacing, argument and voice. The heavy lifting that turns a draft into a book, done in collaborative passes with you.",
  },
  {
    n: "03",
    title: "Line edit & proof",
    body: "Sentence-level craft, then two independent proofing passes against a house style sheet built for your title.",
  },
  {
    n: "04",
    title: "Design & typesetting",
    body: "Cover art direction, interior typography, and layout tuned for both a 6-inch e-reader and a printed page.",
  },
  {
    n: "05",
    title: "Production & metadata",
    body: "ePub, Kindle and print-ready PDF exports, ISBN assignment, BISAC categories, keywords and copyright registration.",
  },
  {
    n: "06",
    title: "Release",
    body: "Retailer onboarding, pre-order setup, launch scheduling and a live royalty dashboard from day one.",
  },
];

function PublishingPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Service · Publishing"
        title="Manuscript to"
        serifPart="finished book."
        intro="One team, one pipeline, one point of contact — from the first structural read to the day it goes live in forty countries."
        image={pagesMacro}
      />

      <Section>
        <SectionHeading
          eyebrow="The process"
          title="Six steps,"
          serifPart="no guesswork."
          intro="Every title moves through the same pipeline. You always know which stage you're in and what happens next."
        />

        <div className="relative mt-16 pl-8 md:pl-0">
          <span className="absolute top-0 bottom-0 left-[3px] w-px bg-gradient-to-b from-primary via-primary/40 to-transparent md:left-1/2" />
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.06}>
              <div
                className={`relative flex py-9 md:w-1/2 ${
                  i % 2 ? "md:ml-auto md:pl-14" : "md:pr-14 md:text-right"
                }`}
              >
                <motion.span
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  className={`absolute top-11 -left-8 size-2 rounded-full bg-primary shadow-[0_0_0_5px_var(--primary-deep)] md:top-11 ${
                    i % 2 ? "md:-left-1" : "md:-right-1 md:left-auto"
                  }`}
                />
                <div>
                  <span className="font-serif text-4xl font-light text-primary/50">
                    {s.n}
                  </span>
                  <h3 className="mt-3 text-2xl font-medium">{s.title}</h3>
                  <p className="mt-3 leading-relaxed text-muted-foreground">{s.body}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <ImageReveal
            src={editorialWriter}
            alt="A writer at work by lamplight"
            className="aspect-[4/3] rounded-xl"
            parallax={40}
          />
          <div>
            <SectionHeading
              eyebrow="Formats"
              title="Everywhere a reader"
              serifPart="might be."
              intro="Every title ships as ePub, Kindle-ready MOBI/KPF and a print-ready PDF, with a hardback and paperback available through print-on-demand."
            />
            <ButtonLink to="/contact" className="mt-9" magnetic>
              Start your book
            </ButtonLink>
          </div>
        </div>
      </Section>

      <section className="relative flex min-h-[45vh] items-center overflow-hidden border-t border-border">
        <div className="duotone absolute inset-0">
          <img
            src={bookStack}
            alt=""
            aria-hidden
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative mx-auto w-full max-w-4xl px-6 text-center">
          <h2 className="font-serif text-3xl leading-tight font-light italic md:text-5xl">
            “They took a manuscript I'd sat on for four years and turned it into a
            book I'm proud to hand to anyone.”
          </h2>
          <p className="mt-6 text-[0.7rem] tracking-[0.26em] text-primary uppercase">
            Elena Rostova
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}
