import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { ServiceDetailPage } from "@/components/service-page";

import svcPodcast from "@/assets/svc-podcast.jpg";
import studioMic from "@/assets/studio-mic.jpg";
import inkTexture from "@/assets/ink-texture.jpg";

const TITLE = "Podcast Production — Modus Publications";
const DESC =
  "Author-led podcast production: format design, full episode editing, show art, transcripts and guest booking on established shows.";

export const Route = createFileRoute("/podcast")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <ServiceDetailPage
      eyebrow="Service · Podcast"
      title="A book ends."
      serifPart="A show doesn't."
      intro="We turn a finished title into an ongoing conversation — produced, edited and booked, so the author only has to show up and talk."
      heroImage={svcPodcast}
      overview={{
        eyebrow: "The service",
        title: "Your voice,",
        serifPart: "on a schedule.",
        paragraphs: [
          "A book is a single release. A show is a standing appointment with the same readers, every week or every fortnight, for as long as you want to keep it. It is the most reliable audience-building asset an author can own.",
          "We design the format first: length, structure, whether it is solo, interview or narrative, and what a season looks like. Then we handle the production load — remote recording, editing, mixing, show art, episode copy and transcripts.",
          "Alongside your own show, our booking team places you on established podcasts in your category, which is still the fastest way to reach readers who have never heard your name.",
        ],
        image: studioMic,
        imageAlt: "A studio microphone under warm light",
      }}
      benefitsHeading={{
        eyebrow: "Why it matters",
        title: "An audience",
        serifPart: "you keep.",
        intro: "Retail platforms rent you attention. A show is the one channel where the relationship is yours.",
      }}
      benefits={[
        {
          title: "Format design",
          body: "Structure, length and season arc built around your book's subject and the time you can realistically give it.",
        },
        {
          title: "Full production",
          body: "Remote recording direction, editing, mixing, mastering and publishing to every podcast platform.",
        },
        {
          title: "Assets included",
          body: "Show art, episode covers, audiograms, transcripts and show notes written for search.",
        },
        {
          title: "Guest booking",
          body: "Placement on partner and category shows, with prep notes and talking points for each appearance.",
        },
      ]}
      stats={[
        { value: 60, suffix: "+", label: "Shows produced" },
        { value: 900, suffix: "+", label: "Episodes published" },
        { value: 48, suffix: "h", label: "Edit turnaround" },
        { value: 30, suffix: "+", label: "Partner shows" },
      ]}
      stepsHeading={{
        eyebrow: "The process",
        title: "From idea",
        serifPart: "to episode one.",
        intro: "Six weeks from the first format call to a launch block of episodes live on every platform.",
      }}
      steps={[
        {
          n: "01",
          title: "Format and season plan",
          body: "We agree the premise, the cadence, and the first ten episode topics before a microphone is switched on.",
        },
        {
          n: "02",
          title: "Sound and identity",
          body: "Show art, theme music, intro and outro scripting, and a consistent audio signature.",
        },
        {
          n: "03",
          title: "Recording",
          body: "Directed remote sessions with a producer on the line, batched so you record several episodes at once.",
        },
        {
          n: "04",
          title: "Publish and promote",
          body: "Editing, transcripts, distribution to Apple, Spotify and YouTube, plus audiograms for social.",
        },
      ]}
      ctaImage={inkTexture}
      ctaTitle="Let's plan your"
      ctaSerif="first season."
      ctaLabel="Plan a show"
    />
  ),
});
