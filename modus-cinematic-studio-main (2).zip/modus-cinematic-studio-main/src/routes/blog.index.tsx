import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-chrome";
import { PageHero, Section } from "@/components/ui-kit";
import { Reveal, Tilt } from "@/components/motion-primitives";
import { posts } from "@/lib/site-data";
import { coverFor } from "@/lib/post-covers";

import svcPress from "@/assets/svc-press.jpg";

const TITLE = "Journal — Modus Publications";
const DESC =
  "Notes from the studio on publishing economics, author branding, audiobooks, cover design and launch marketing.";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: BlogPage,
});

function BlogPage() {
  const [lead, ...rest] = posts as [(typeof posts)[number], ...typeof posts];

  return (
    <SiteLayout>
      <PageHero
        eyebrow="Journal"
        title="Notes from"
        serifPart="the studio."
        intro="What we're learning about publishing economics, launches, audio and design — written by the people doing the work."
        image={svcPress}
      />

      <Section>
        <Reveal>
          <Link to="/blog/$slug" params={{ slug: lead.slug }} className="block">
          <article className="group grid overflow-hidden rounded-xl border border-border bg-surface/60 transition-all duration-500 hover:border-primary/60 lg:grid-cols-2">
            <div className="relative aspect-[16/10] overflow-hidden lg:aspect-auto">
              <img
                src={coverFor(lead.slug)}
                alt=""
                aria-hidden
                loading="lazy"
                className="h-full w-full object-cover opacity-70 brightness-[0.7] transition-all duration-[1.2s] group-hover:scale-105 group-hover:opacity-100 group-hover:brightness-100"
              />
              <div className="absolute inset-0 bg-[linear-gradient(175deg,transparent,color-mix(in_oklab,var(--primary-deep)_45%,transparent))]" />
            </div>
            <div className="flex flex-col justify-center p-8 md:p-14">
              <div className="flex items-center gap-4 text-[0.65rem] tracking-[0.22em] uppercase">
                <span className="text-primary">{lead.category}</span>
                <span className="text-muted-foreground">{lead.date}</span>
              </div>
              <h2 className="mt-5 font-serif text-3xl leading-tight font-light md:text-5xl">
                {lead.title}
              </h2>
              <p className="mt-5 leading-relaxed text-muted-foreground">
                {lead.excerpt}
              </p>
              <span className="mt-8 inline-flex items-center gap-2 text-[0.7rem] tracking-[0.2em] text-primary uppercase">
                Read the piece
                <span className="transition-transform duration-300 group-hover:translate-x-1.5">
                  →
                </span>
              </span>
            </div>
          </article>
          </Link>
        </Reveal>

        <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {rest.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.07} className="h-full">
              <Tilt strength={5} className="h-full">
                <Link to="/blog/$slug" params={{ slug: p.slug }} className="block h-full">
                <article className="group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface/60 transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/60 hover:shadow-[0_28px_70px_-30px_var(--primary)]">
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={coverFor(p.slug)}
                      alt=""
                      aria-hidden
                      loading="lazy"
                      className="h-full w-full object-cover opacity-65 brightness-[0.65] transition-all duration-[1.2s] group-hover:scale-108 group-hover:opacity-100 group-hover:brightness-100"
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(175deg,transparent,color-mix(in_oklab,var(--primary-deep)_45%,transparent))]" />
                  </div>
                  <div className="flex flex-1 flex-col p-6">
                    <div className="flex items-center gap-3 text-[0.6rem] tracking-[0.22em] uppercase">
                      <span className="text-primary">{p.category}</span>
                      <span className="text-muted-foreground">{p.date}</span>
                    </div>
                    <h3 className="mt-4 font-serif text-xl leading-snug font-light">
                      {p.title}
                    </h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                      {p.excerpt}
                    </p>
                    <span className="mt-auto pt-6 text-[0.65rem] tracking-[0.2em] text-primary uppercase">
                      Read more →
                    </span>
                  </div>
                </article>
                </Link>
              </Tilt>
            </Reveal>
          ))}
        </div>
      </Section>
    </SiteLayout>
  );
}
