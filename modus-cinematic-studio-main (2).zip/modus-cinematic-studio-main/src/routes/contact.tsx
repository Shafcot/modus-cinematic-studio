import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { SiteLayout } from "@/components/site-chrome";
import { Button, PageHero, Section } from "@/components/ui-kit";
import { Reveal } from "@/components/motion-primitives";
import {
  ADDRESS,
  CONTACT_EMAIL,
  WHATSAPP_DISPLAY,
  WHATSAPP_URL,
  services,
} from "@/lib/site-data";

import inkTexture from "@/assets/ink-texture.jpg";

const TITLE = "Contact — Modus Publications";
const DESC =
  "Tell us about your book. Editorial, design, publishing, audiobooks and marketing — one team, one point of contact.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: ContactPage,
});

const field =
  "w-full rounded-lg border border-border bg-surface/60 px-4 py-3.5 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary";
const label = "mb-2 block text-[0.65rem] tracking-[0.22em] text-muted-foreground uppercase";

function ContactPage() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    service: services[0]!.title,
    message: "",
  });

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const subject = `New enquiry — ${form.service}`;
    const body = `Name: ${form.name}\nEmail: ${form.email}\nService: ${form.service}\n\n${form.message}`;
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(
      subject,
    )}&body=${encodeURIComponent(body)}`;
    setSent(true);
  }

  return (
    <SiteLayout>
      <PageHero
        eyebrow="Contact"
        title="Good things happen when"
        serifPart="you say hey."
        intro="Tell us what you're working on. We reply to every enquiry within 24 hours."
        image={inkTexture}
      />

      <Section>
        <div className="grid gap-14 lg:grid-cols-[1.3fr_1fr]">
          <Reveal>
            {sent ? (
              <div className="rounded-2xl border border-border bg-surface/60 p-7 sm:p-10">
                <p className="eyebrow text-primary">Enquiry received</p>
                <h2 className="mt-4 font-serif text-3xl leading-tight font-light sm:text-4xl">
                  Thank you, {form.name.split(" ")[0] || "there"} — we'll reply within 24 hours.
                </h2>
                <p className="mt-5 leading-relaxed text-muted-foreground">
                  Your enquiry about{" "}
                  <span className="text-foreground">{form.service}</span> is on its way. Your
                  email app should have opened with the message ready to send — if it didn't,
                  write to us directly at{" "}
                  <a href={`mailto:${CONTACT_EMAIL}`} className="text-primary">
                    {CONTACT_EMAIL}
                  </a>{" "}
                  or message us on{" "}
                  <a
                    href={WHATSAPP_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="text-primary"
                  >
                    WhatsApp
                  </a>
                  .
                </p>
                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <Button
                    type="button"
                    onClick={() => {
                      setSent(false);
                      setForm({
                        name: "",
                        email: "",
                        service: services[0]!.title,
                        message: "",
                      });
                    }}
                  >
                    Send another enquiry
                  </Button>
                </div>
              </div>
            ) : (
            <form onSubmit={onSubmit} className="space-y-6">
              <div className="grid gap-6 sm:grid-cols-2">
                <div>
                  <label className={label} htmlFor="name">
                    Name
                  </label>
                  <input
                    id="name"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Your name"
                    className={field}
                  />
                </div>
                <div>
                  <label className={label} htmlFor="email">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="you@example.com"
                    className={field}
                  />
                </div>
              </div>

              <div>
                <label className={label} htmlFor="service">
                  Service you're interested in
                </label>
                <select
                  id="service"
                  value={form.service}
                  onChange={(e) => setForm({ ...form, service: e.target.value })}
                  className={field}
                >
                  {services.map((s) => (
                    <option key={s.slug} value={s.title} className="bg-background">
                      {s.title}
                    </option>
                  ))}
                  <option value="Not sure yet" className="bg-background">
                    Not sure yet
                  </option>
                </select>
              </div>

              <div>
                <label className={label} htmlFor="message">
                  Message
                </label>
                <textarea
                  id="message"
                  required
                  rows={6}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Where are you with the book, and what do you need?"
                  className={`${field} resize-none`}
                />
              </div>

              <Button type="submit" className="w-full sm:w-auto">
                Send enquiry
              </Button>
            </form>
            )}
          </Reveal>

          <Reveal delay={0.15}>
            <div className="space-y-10">
              <div>
                <p className="eyebrow mb-3">Email</p>
                <a
                  href={`mailto:${CONTACT_EMAIL}`}
                  className="font-serif text-2xl font-light transition-colors hover:text-primary"
                >
                  {CONTACT_EMAIL}
                </a>
              </div>
              <div>
                <p className="eyebrow mb-3">WhatsApp</p>
                <a
                  href={WHATSAPP_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="font-serif text-2xl font-light transition-colors hover:text-primary"
                >
                  {WHATSAPP_DISPLAY}
                </a>
              </div>
              <div>
                <p className="eyebrow mb-3">Studio</p>
                <p className="leading-relaxed text-muted-foreground">
                  Modus Publications
                  <br />
                  A subsidiary of ModusVenture
                  <br />
                  {ADDRESS}
                </p>
              </div>
              <div>
                <p className="eyebrow mb-3">Response time</p>
                <p className="leading-relaxed text-muted-foreground">
                  Every enquiry gets a reply from a person within 24 hours,
                  usually with a first read on what your book needs.
                </p>
              </div>
              <div className="hairline" />
              <p className="font-serif text-xl leading-snug font-light italic text-muted-foreground">
                “From finished manuscript to bestseller — under one roof.”
              </p>
            </div>
          </Reveal>
        </div>
      </Section>
    </SiteLayout>
  );
}
