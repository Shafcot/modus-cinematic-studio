import { OG_IMAGE } from "@/lib/site-data";
import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-chrome";
import { ButtonLink, Card, PageHero, Section, SectionHeading } from "@/components/ui-kit";
import { ImageReveal, Reveal, Tilt } from "@/components/motion-primitives";

import authorPortrait from "@/assets/author-portrait.jpg";
import knowUsCity from "@/assets/know-us-city.jpg";
import inkTexture from "@/assets/ink-texture.jpg";
import pagesMacro from "@/assets/pages-macro.jpg";
import bookStack from "@/assets/book-stack.jpg";
import editorialWriter from "@/assets/editorial-writer.jpg";

const TITLE = "Author Branding — Modus Publications";
const DESC =
  "Positioning, visual identity, author websites and media kits that make a name unmistakable long after launch week.";

export const Route = createFileRoute("/author-branding")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: AuthorBrandingPage,
});

const pillars = [
  {
    title: "Positioning",
    body: "The one sentence that says who you write for and why they should care. Everything else hangs off it.",
  },
  {
    title: "Visual identity",
    body: "Wordmark, typography, colour and a photography direction that survives a book cover, a billboard and a podcast tile.",
  },
  {
    title: "Author site",
    body: "A fast, editorial site with a book shelf, press page, newsletter capture and a media kit journalists can actually use.",
  },
  {
    title: "Voice & social",
    body: "Tone guidelines and a posting architecture so your presence reads like you, not like a marketing department.",
  },
];

const portfolio = [
  { name: "Elena Rostova", note: "Business · strategy", img: authorPortrait },
  { name: "Isabel Moreau", note: "Literary fiction", img: knowUsCity },
  { name: "James Chen", note: "Technology", img: inkTexture },
  { name: "Amara Osei", note: "Self-improvement", img: pagesMacro },
  { name: "Dr. Priya Sharma", note: "Science", img: editorialWriter },
  { name: "Marcus Webb", note: "Creativity", img: bookStack },
];

function AuthorBrandingPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Service · Author Branding"
        title="An author is a brand"
        serifPart="before the book is a product."
        intro="We build the positioning, identity and presence that make a name memorable long after the launch week ends."
        image={authorPortrait}
      />

      <Section>
        <SectionHeading eyebrow="Four pillars" title="What we" serifPart="build." />
        <div className="mt-14 grid gap-5 md:grid-cols-2">
          {pillars.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.07}>
              <Card glow className="h-full p-8">
                <span className="font-serif text-4xl font-light text-primary/40">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-5 text-2xl font-medium">{p.title}</h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">{p.body}</p>
              </Card>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <SectionHeading
          eyebrow="Selected work"
          title="Authors we've"
          serifPart="shaped."
        />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {portfolio.map((p, i) => (
            <Reveal key={p.name} delay={i * 0.06}>
              <Tilt strength={7}>
                <div className="group relative overflow-hidden rounded-xl border border-border transition-all duration-500 hover:border-primary/60 hover:shadow-[0_30px_80px_-30px_var(--primary)]">
                  <div className="duotone relative aspect-[4/5]">
                    <img
                      src={p.img}
                      alt={p.name}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-[1.4s] group-hover:scale-108"
                    />
                  </div>
                  <div className="absolute inset-x-0 bottom-0 z-10 p-6">
                    <h3 className="font-serif text-xl font-light">{p.name}</h3>
                    <p className="mt-1 text-[0.65rem] tracking-[0.22em] text-primary uppercase">
                      {p.note}
                    </p>
                  </div>
                </div>
              </Tilt>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section className="border-t border-border">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <ImageReveal
            src={inkTexture}
            alt="Ink bleeding through paper"
            className="aspect-[4/3] rounded-xl"
            parallax={40}
          />
          <div>
            <SectionHeading
              eyebrow="Get started"
              title="Let's define"
              serifPart="your name."
              intro="A branding engagement starts with a two-hour positioning session. You leave that call with a sharper answer to 'what do you write?' than you had going in."
            />
            <ButtonLink to="/contact" className="mt-9" magnetic>
              Book a session
            </ButtonLink>
          </div>
        </div>
      </Section>
    </SiteLayout>
  );
}
