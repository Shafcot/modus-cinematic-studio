# Modus Cinematic

Build a premium, dark-themed website for Modus Publications, a full-service ebook publishing house that also operates like a creative digital studio. The site should feel like a hybrid of a high-end creative agency and a boutique publishing house — polished, cinematic, editorial, and slightly techy. This is not a generic "book selling" template — treat it as a brand showcase first, catalog second.

Brand identity
Logo: a bold red "M" mark (chevron/arrow style) next to serif wordmark "MODUS PUBLICATIONS"
Primary accent color: deep red, hex #E24B4A (with a darker red #A32D2D for hover/depth states and a near-black red #501313 for shadows/gradients)
Base palette: near-black backgrounds (#0A0A0B, #121214), off-white text (#F5F5F3), muted gray for secondary text (#8A8A8E)
Overall theme: dark mode only. No light sections. Use subtle red glows, thin red accent lines, and red gradient overlays sparingly to punctuate sections — never overwhelm.
Typography: pair a modern grotesk/techy sans-serif for UI and headings (Space Grotesk, General Sans, or Inter Tight) with a refined serif (Fraunces, Canela, or Playfair Display) used only for editorial moments — big pull quotes, book titles, hero headline accents. This sans+serif contrast should read as "creative studio meets publishing house."
Imagery — this is not optional, treat it as a primary requirement
The single biggest visual failure mode for this build is a text-and-cards site with no real imagery. Every major section below must include actual visual content, not just typography on a flat background. Since Lovable can't generate custom photography, source images from Unsplash (https://source.unsplash.com or unsplash.com direct links) using queries like "moody dark library," "open book dramatic lighting," "writer typing dark room," "vintage typewriter," "book pages macro," "author portrait black and white," "city skyline night red light," "abstract ink and paper texture." Use these as full-bleed section backgrounds, image reveal panels, and card imagery — not small decorative thumbnails. Every image should be treated with a dark overlay/duotone (black to red gradient wash) so it fits the theme instead of looking pasted in.

Scroll animation — make it the spine of the site, not a garnish
Use Framer Motion (or GSAP with ScrollTrigger if richer control is needed) for a genuinely cinematic scroll experience:

Image reveal on scroll — images clip-path or scale in from 80% to 100% as they enter viewport, with a slight fade and upward translate
Parallax layers — background images move slower than foreground text on scroll (at least in the hero and the "Know us" section) for real depth
Pinned/sticky sections — consider pinning the hero text while a background image or the type-marquee continues moving, releasing on scroll
Staggered text reveals — headlines and paragraphs animate in word-by-word or line-by-line (stagger children) rather than appearing as one block
Cursor-reactive elements — book cards and service cards tilt slightly toward the cursor (subtle 3D tilt, like a physical object), buttons have a magnetic pull toward the pointer
Number count-up animations — any stats (books published, authors, campaigns) count up from 0 when scrolled into view
Smooth scroll — implement Lenis or a similar smooth-scroll library so the whole page feels fluid, not native-jumpy
Motion should feel expensive and intentional — not gimmicky spam, but every section should have at least one deliberate animation moment tied to scroll position, not just a fade-in.

Global structure (build all pages, linked in nav)
Top nav (sticky, transparent-to-solid on scroll): Home · Services · Publishing · Author Branding · Author Marketing · Audiobooks · Catalog · Blog · Contact — plus the Modus logo left-aligned and a "Start a project" CTA button right-aligned.

Footer on every page: logo + tagline, quick links to all pages, contact email (info@modusventure.com), social icons, "Modus Publications — a subsidiary of ModusVenture."

Homepage (this is the priority page — make it a 10/10 visual showcase)
Hero section — full-bleed, full-viewport-height background image (moody dark library or open-book macro shot from Unsplash, dark red-to-black duotone overlay) with a slow Ken Burns zoom on load. Layer a subtle animated red gradient mesh or particle/line texture on top for depth. Large serif+sans mixed headline: "Stories that move you." animates in line-by-line, with a smaller techy sans subhead: "From finished manuscript to bestseller — writing, editing, design, publishing, and marketing under one roof." Two CTAs: "Browse catalog" (outline button) and "Start your book" (solid red button, magnetic hover). Add a scroll-down indicator with subtle bounce motion. As the user scrolls, the background image parallaxes slower than the text.

Marquee/ticker strip — a large, dominant horizontally auto-scrolling row of italic/serif words (bigger type than body copy, closer to a display headline) like the reference agency site style: "publishing · author branding · global distribution · audiobooks · marketing · press · ", looping infinitely, low-opacity red divider dots between words. This should feel like a bold visual statement, not a small ticker.

Full-bleed editorial image break — a single full-width image (writer at a desk, dramatic lighting, or a stack of books) with a large serif pull-quote overlaid, text revealing on scroll with a clip-path wipe animation. This section exists purely to give the page a breathing, cinematic moment between content blocks.

Featured titles — a horizontal scroll or grid of 4 book covers in card format, each with title, author, price, "Bestseller"/"New" tag badge, rendered as tilted/floating cards with 3D cursor-tilt and hover lift plus shadow-glow (red glow, not generic drop shadow). Cards scale in from slightly below full size as they scroll into view.

Services overview grid — 4-7 cards (Publishing, Global Publishing, Author Branding, Author Marketing, Audiobooks, Podcast, Times Square Advertising, Press Releases) each with a background thumbnail image (subtle, dark-treated) behind a minimal line icon, short one-line description, and a red arrow link. Cards have a thin border that lights up red on hover, and the background image slightly zooms on hover.

"The Modus difference" — stats strip — 4-column feature strip mixing large serif numerals (01–04, Curated Selection / Instant Delivery / Read Anywhere / Personal Support) with a second row of real count-up statistics (e.g. books published, authors represented, countries reached) that animate from 0 when scrolled into view.

Know us / about section — split layout: large full-height editorial image (portrait-style, moody, Karachi/London city or studio shot) on one side with parallax scroll, short brand story copy on the other ("Born in the chaos and color of Karachi... now building with visionaries across London and beyond"), with a "Our story" link. Image should have a subtle scale-in reveal as it enters view.

Testimonials — auto-rotating or scroll-snap carousel of client quotes with name + company, each card paired with a small circular client/company image or initials avatar, red quote mark accent, cards fade and slide in on scroll.

Client logos / trust strip — grayscale logos that go full color/red-tinted on hover, fading in as a staggered row when scrolled into view.

Final CTA banner — full-width section with a dark, textured background image (abstract ink/paper or dramatic red-black gradient photo), bold serif headline "Good things happen when you say hey." fading/scaling in, and a single centered "Get in touch" button with magnetic hover effect.

Pull actual homepage copy, book titles, testimonials, and service descriptions from https://ebook.modusventure.com/ — Lovable should fetch/reference this URL for real content instead of placeholder text.

Additional pages (build simpler, consistent with the design system above)
Services — full list of all 8 services (Publishing, Global Publishing, Author Branding, Author Marketing, Audiobooks, Podcast, Times Square Advertising, Press Releases) each as an expandable row or full section with title, description, and a relevant visual/icon, styled like the homepage services grid but in more depth.
Publishing — deep dive page on the end-to-end publishing service (manuscript to finished book), process timeline component (numbered steps with connecting line, red accent).
Author Branding — service page focused on author identity/positioning, portfolio-style examples grid.
Author Marketing — service page on campaigns/marketing, could include a stats/metrics strip (books launched, campaigns run, etc.).
Audiobooks — service page on narration/audiobook production and distribution, with a stylized audio waveform visual element.
Catalog — grid of all books with filter by genre (Fiction, Business, Self-Improvement, Technology, Science, History, Design), search bar, book cards matching homepage style.
Blog — article grid/list with featured image, title, excerpt, date.
Contact — clean contact form (name, email, message, service interested in) plus company details/address, styled minimally with the same dark theme.
Technical notes for Lovable
Use Tailwind CSS with a custom dark theme config (background, foreground, accent-red variables).
Use Framer Motion for all animations (whileInView reveals, staggered children for text, hover scale/glow, marquee loop, count-up numbers) and add Lenis for smooth scroll. Every section listed above must ship with its described image and its described scroll animation — do not simplify sections down to flat color backgrounds with no imagery, and do not reduce animations to plain opacity fades only.
Source every background/section image from Unsplash with a dark red-black duotone overlay so imagery reads as intentional and on-brand rather than stock-photo generic.
Keep the build efficient: reuse a shared Card, Button, SectionHeading, and Nav/Footer component across all pages rather than rebuilding per page.
Make it fully responsive (mobile nav collapses to a hamburger menu with full-screen dark overlay).
Prioritize building the homepage fully first, then scaffold the remaining pages using the same design tokens and components so they feel native to the brand rather than generic templated pages.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://modus-cinematic-studio.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/250ddb90-37ea-4c93-8f86-4e8a8388e66b).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
