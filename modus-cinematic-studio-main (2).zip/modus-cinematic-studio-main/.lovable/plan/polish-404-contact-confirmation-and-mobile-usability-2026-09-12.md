# Polish 404, contact confirmation, and mobile usability

## Changes
- Replace the generic unmatched-URL screen with an on-brand Modus page using the logo, concise “missing or moved” copy, a primary Home action, and a Catalog link.
- Turn the contact form into a clear submitted state after launch: replace the form with a success panel confirming the enquiry and expected 24-hour response window, while preserving direct contact details.
- Audit all public pages at 375–430px and apply shared mobile fixes for side margins, section spacing, full-card tap areas, control sizing, and menu usability.
- Address route-specific mobile overflow or cramped controls found during the audit without changing desktop layout or site content.

## Verification
- Test an unknown URL and confirm both destinations work.
- Submit the contact form and confirm the success state appears clearly.
- Check every public route at 375px and 430px for horizontal overflow, readable margins, and practical touch targets.
- Confirm the project builds cleanly with no browser errors.

## Technical details
- Keep routing in TanStack Router and use the existing shared Modus components and semantic design tokens.
- Use the shared site layout for the 404 so navigation and footer remain consistent.
- Preserve the email-based enquiry behavior; this pass adds visible confirmation rather than server-side message storage.
